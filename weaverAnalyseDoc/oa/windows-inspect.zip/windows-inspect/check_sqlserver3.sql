IF EXISTS(SELECT * FROM sys.tables WHERE SCHEMA_NAME(schema_id) LIKE 'dbo' AND name like 'check_db_info')  
   DROP TABLE [dbo].check_db_info;  
GO

create table check_db_info(id int,item varchar(100),result varchar(15),info varchar(100),check_date datetime);
GO

IF EXISTS(SELECT * FROM sys.procedures WHERE SCHEMA_NAME(schema_id) LIKE 'dbo' AND name like 'weaver_db_check_sqlserver')  
   DROP procedure [dbo].weaver_db_check_sqlserver;  
GO

if EXISTS (select * from sys.sysobjects where xtype='fn' and name='kljrpad')
if EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].[kljrpad]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[kljrpad]
GO

IF EXISTS(SELECT * FROM sys.procedures WHERE SCHEMA_NAME(schema_id) LIKE 'dbo' AND name like 'kljrpad')  
   DROP function [dbo].kljrpad;  
GO


IF EXISTS(SELECT * FROM sys.tables WHERE SCHEMA_NAME(schema_id) LIKE 'dbo' AND name like 'Weaver_DiskSpace')  
   DROP TABLE [dbo].Weaver_DiskSpace;  
GO

create table Weaver_DiskSpace(DISK_Drive varchar(2), MBfree int );
GO    

create function kljrpad
(@s nvarchar(255),@length int,@char char(1))
returns nvarchar(255)
as
begin
declare @padded_string nvarchar(255) 
declare @pad_string nvarchar(255) 
declare @pad_length int 
declare @i int 
if @length<len(@s)
	return right(@s,@length)

set @pad_length=@length-len(@s)
set @i=0
while(@i<@pad_length)
begin
	set @pad_string=isnull(@pad_string,'')+@char
	set @i=@i+1
end

set @padded_string=@s+@pad_string
return @padded_string
end
GO


create procedure weaver_db_check_sqlserver 
AS
BEGIN
declare @oauser varchar(30)
declare @oadbname varchar(30)
set @oauser=system_user;
Select @oadbname=[Name] From Master..SysDataBases Where DbId=(Select Dbid From Master..SysProcesses Where Spid = @@spid);

--select @oauser

insert into check_db_info
select 1,'���ݿ�汾���'  ,case when versions    not like '%express%' then '���ͨ��' else '��鲻ͨ��' end,'��ǰ���ݿ�汾='+ REPLACE (lower(convert(varchar,SERVERPROPERTY('Edition'))), ' ', '' ),getdate() 
from (
SELECT     'version check' item,REPLACE (lower(convert(varchar,SERVERPROPERTY('Edition'))), ' ', '' )  AS versions
) a;

insert into check_db_info
 select 2,'������뼶����(is_read_committed_snapshot_on=1)',case when is_read_committed_snapshot_on = 1 then '���ͨ��' else '��鲻ͨ��' end ,'��ǰis_read_committed_snapshot_on='+ convert(varchar,is_read_committed_snapshot_on),getdate()
  from sys.databases where name=@oadbname;
  
 insert into check_db_info
  select 3,'�û�������ڼ��(is_expiration_checked=0)',case when is_expiration_checked = 0 then '���ͨ��' else '��鲻ͨ��'  end ,'��ǰis_expiration_checked='+ convert(varchar,is_expiration_checked),getdate() 
  from sys.sql_logins where name=@oauser;

insert Weaver_DiskSpace exec master.dbo.xp_fixeddrives;
     
--select * from Weaver_DiskSpace   ;   
insert into check_db_info
select 4,'���ݿ���̿��пռ�(>=300GB)',case when  mbfree>=307200 then '���ͨ��' else '��鲻ͨ��' end ,
case when mbfree>=307200 then '��ǰ���̿ռ����'  else '��ǰDB���̿��пռ䲻��,��ǰΪ��'+ convert(varchar,mbfree)+'MB' end,getdate()
from( 
select * from (     
select a.*,ROW_NUMBER() OVER(Order by mbfree asc ) AS RowId  from (
select * from 
      ( select SUBSTRING(physical_name,1,1) dir1   from  sys.database_files group by SUBSTRING(physical_name,1,1) ) disk2,Weaver_DiskSpace disk1
      where disk2.dir1=disk1.DISK_Drive     
      ) a
      ) b where RowId=1
      ) c;


insert into check_db_info
   select 5,'�����ļ���չ���(is_percent_growth)',case when cnt=0 then  '���ͨ��' else '��鲻ͨ��' end,'�����ļ���չ:is_percent_growth='+ convert(varchar,cnt) ,getdate()
  from
  (select sum(case when is_percent_growth=1 then 1 else 0 end) as cnt from sys.database_files where type_desc='ROWS' 
  ) a;
  

insert into check_db_info
  select 6,'��־�ļ���չ���(is_percent_growth=0)',case when cnt=0 then  '���ͨ��' else '��鲻ͨ��' end,'��־�ļ���չ:is_percent_growth='+ convert(varchar,cnt) ,getdate()
  from
  (select sum(case when is_percent_growth=1 then 1 else 0 end) as cnt from sys.database_files where type_desc='LOG' 
  ) a;
  

insert into check_db_info
    select 7,'���ݿⱸ�ݼ��',case when cnt>=1 then  '���ͨ��' else '��鲻ͨ��' end,'���ݿ��������:'+ convert(varchar,backupdate,25) ,getdate()
    from (
         SELECT sum(1) cnt,MAX(backup_finish_date) backupdate
	       FROM msdb.dbo.backupmediafamily
			INNER JOIN msdb.dbo.backupset ON msdb.dbo.backupmediafamily.media_set_id = msdb.dbo.backupset.media_set_id
			WHERE msdb.dbo.backupset.type = 'D'
			and backup_finish_date>=GETDATE()-300
			and database_name=@oadbname
			) a;
			
insert into check_db_info
  select 8,'�ڴ���(>=16G)',case when total_physical_memory_kb*1024>=17179869184 then '���ͨ��' else '��鲻ͨ��' end ,'��ǰOS�ڴ�='+ convert(varchar,round(total_physical_memory_kb/1024/1024,4,1))+'G',getdate()
    from sys.dm_os_sys_memory ;
    

insert into check_db_info
  select 9,'CPU�������(>=8)',case when cpu_count>=8 then '���ͨ��' else '��鲻ͨ��' end ,'��ǰCPU����='+ convert(varchar,cpu_count) ,getdate()
   from sys.dm_os_sys_info ;
   

insert into check_db_info
  select 10,'�ַ�����ؼ��(Chinese_PRC_CI_AS)',case when collation_name = 'Chinese_PRC_CI_AS' then '���ͨ��' else '��鲻ͨ��' end ,'��ǰcollation_name='+ convert(varchar,collation_name),getdate()
   from sys.databases where name=@oadbname;
   
insert into check_db_info
  select 11,'������־��С���(<30720M)',case when spaceusermb<30720 then '���ͨ��' else '��鲻ͨ��' end ,'��ǰ������־��С='+ convert(varchar,spaceusermb)+'M',getdate()
    from (SELECT cast(a.[size]*1.0/128 as decimal(12,1)) AS  fileseizemb,CAST( fileproperty(s.name,'SpaceUsed')/(8*16.0) AS DECIMAL(12,1)) AS spaceusermb
		    FROM sys.database_files  a
			INNER JOIN sys.sysfiles AS s ON a.[file_id]=s.fileid
			LEFT JOIN sys.dm_db_file_space_usage b ON a.[file_id]=b.[file_id]
			where type_desc='LOG' ) A;
			
insert into check_db_info
  select 12, 'License���',case when 1=1 then '���ͨ��' else '��鲻ͨ��' end ,'��ǰ�ͻ�:'+ REPLACE (lower(convert(varchar,companyname)), ' ', '' )+'M',getdate()
    from license;			
		
--select "���μ����......"   

--select dbo.kljrpad(id,3,' ') id,dbo.kljrpad(item,30,' ') item,dbo.kljrpad(result,15,' ') result,dbo.kljrpad(info,120,' ') info,dbo.kljrpad( convert(varchar,check_date,25),25,' ') check_date  from check_db_info;    
--select * from check_db_info order by result;  
select convert(varchar,id)+'|'+item+'|'+result+'|'+isnull(info,'û�м����Ϣ')+'|'+convert(varchar,check_date,25) from check_db_info order by result; 
--SELECT system_user;
--Select Name From Master..SysDataBases Where DbId=(Select Dbid From Master..SysProcesses Where Spid = @@spid);
 
END  