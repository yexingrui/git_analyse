#!/bin/bash
#---------------------------------------------------------------------------
# File: testmenu.sh
# Created Date: 2021-02-24
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# 
# Last Modified: Monday July 25th 2022 3:46:33 pm
# 
# Copyright (c) 2021 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
export LANG=en_US.utf8
export LC_ALL=en_US.utf8
# 获取脚本所在绝对路径
SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
# 引入基本巡检脚本
# . "$SHELL_FOLDER"/baseinspect.sh

function log_gen() {
    IPADDR="$(get_ip)"
    SimpleRESULTFILE="SimpleHost_Inspection-$IPADDR-$(date +%Y%m%d%H%M).txt"
    # echo $RESULTFILE
}
function menu ()
{
 echo -e "\033[35m ---------------------------------------
|************Menu Home Page ************|
----------------------------------------\033[0m"


PS3="Enter Option: "
select option in  "OA_Ecology_Inspect" "EMP_Insepct" "Redis_Insepct" "Nginx_Inspect"  "Oracle_Inspect" "MySQL_Inspect" "Tomcat-Ecology" "OtherOS-Ecology" "NFS_Inspect" "Exit menu"
do 
    case $option in
    "Exit menu")
        exit 0
        ;;
    "OA_Ecology_Inspect")
        bash getCollection-menu.sh -t menu
        menu
          ;;
    "EMP_Insepct")
        bash emobile_hostcheck.sh
        menu
         ;;
    "Redis_Insepct")
        bash redischeck.sh
        menu
         ;;
    "Nginx_Inspect")
        bash nginx_inspect.sh
        menu
         ;;
    "Oracle_Inspect")
        bash oracle_hostcheck.sh
        menu
         ;;
    "MySQL_Inspect")
        bash mysql_inspect.sh
        menu
         ;;
    "Tomcat-Ecology")
        bash getCollection-menu-tomcat.sh -t menu
        menu
         ;;
    "OtherOS-Ecology")
        bash oa-simple.sh -t menu
        menu
         ;;
    "NFS_Inspect")
        bash nfscheck.sh
        menu
         ;;
    *)
        clear
        echo "sorry,wrong selection" ;;
    esac
done
clear
}

menu