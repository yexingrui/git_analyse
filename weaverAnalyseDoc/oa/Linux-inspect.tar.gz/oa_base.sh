#!/bin/bash
#---------------------------------------------------------------------------
# File: oa_base.sh
# Created Date: 2022-04-14
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# Last Modified: Friday June 2nd 2023 1:48:16 pm
# Copyright (c) 2022 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
# oa通用性能巡检规则,无关平台,中间件
# 获取脚本所在绝对路径
SHELL_FOLDER=$(
    cd "$(dirname "$0")"
    pwd
)

export LANG=en_US.utf8
export LC_ALL=en_US.utf8

# 代码扫描 名称 $1 序号$2 class路径 $3 关键字 $4 描述 $5
function CodeScan() {
    if [ -f $oaPath/WEB-INF/ecology.ver ]; then
        RequestFormBizDecomplieCode=$($jdkPath/bin/java -jar jd-cli.jar $oaPath/$3)
        GrepResult=$(echo $RequestFormBizDecomplieCode | grep "$4" | wc -l)
        if [ $GrepResult -eq 0 ]; then
            # 文件不包含关键字,检测通过
            tab_mod $2 "$1" "true" "true" "$5"
        else
            #找到关键字,检测不通过
            tab_mod $2 "$1" "false" "true" "$5"
        fi
    fi
}
# 代码扫描：grep支持正则
function CodeScanE() {
    if [ -f $oaPath/WEB-INF/ecology.ver ]; then
        RequestFormBizDecomplieCode=$($jdkPath/bin/java -jar jd-cli.jar $oaPath/$3)
        GrepResult=$(echo $RequestFormBizDecomplieCode | grep -E "$4" | wc -l)
        if [ $GrepResult -eq 0 ]; then
            # 文件不包含关键字,检测通过
            tab_mod $2 "$1" "true" "true" "$5"
        else
            #找到关键字,检测不通过
            tab_mod $2 "$1" "false" "true" "$5"
        fi
    fi
}
function CodeScan2() {
    if [ -f $oaPath/WEB-INF/ecology.ver ]; then
        RequestFormBizDecomplieCode=$($jdkPath/bin/java -jar jd-cli.jar $oaPath/$3)
        GrepResult=$(echo $RequestFormBizDecomplieCode | grep "$4" | wc -l)
        if [ $GrepResult -gt 0 ]; then
            # 找到修改后的代码,检测通过
            tab_mod $2 "$1" "true" "true" "$5"
        else
            #找到关键字,检测不通过
            tab_mod $2 "$1" "false" "true" "$5"
        fi
    fi
}
function JsBaseMain() {
    # 统一处理js问题
    # 名称 $1 序号$2 js路径 $3 关键字 $4 描述 $5
    if [ -f $oaPath/$3 ]; then
        RequestJSDecomplieCode=$(cat $oaPath/$3)
        GrepResult=$(echo $RequestJSDecomplieCode | grep "$4" | wc -l)
        if [ $GrepResult -gt 0 ]; then
            # 找到关键字 不通过
            tab_mod $2 "$1" "false" "true" "$5"
        else
            # 找到关键字 通过
            tab_mod $2 "$1" "true" "true" "$5"
        fi
    fi
}
function JsBaseMain2() {
    # 统一处理js问题
    # 名称 $1 序号$2 js路径 $3 关键字 $4 描述 $5
    if [ -f $oaPath/$3 ]; then
        RequestJSDecomplieCode=$(cat $oaPath/$3)
        GrepResult=$(echo $RequestJSDecomplieCode | grep "$4" | wc -l)
        if [ $GrepResult -gt 0 ]; then
            # 找到关键字 通过
            tab_mod $2 "$1" "true" "true" "$5"
        else
            # 找到关键字 不通过
            tab_mod $2 "$1" "false" "true" "$5"
        fi
    fi
}

function oa_base_main() {
    # 流程节点未正确用事务导致的数据库锁问题导致宕机
    # D:\weaver\ecology\classbean\weaver\workflow\workflow\WFNodeMainManager.class
    # tomcat与resin类路径不一致
    if [ -f $resinPath/bin/resin.sh ]; then
        classPath="classbean"
    else
        classPath="WEB-INF/classes"
    fi
    CodeScan "WFNodeMainManager" "45" "$classPath/weaver/workflow/workflow/WFNodeMainManager.class" "deleteCreateNodeGroupDetail(String nodeid, RecordSetTrans rst)" "流程节点优化"

    #更新流程操作节点造成数据库锁问题
    #D:\weaver\ecology\classbean\com\engine\workflow\biz\requestForm\RequestFormBiz.class
    CodeScan "RequestFormBiz" "46" "$classPath/com/engine/workflow/biz/requestForm/RequestFormBiz.class" "(recordSet.getDBType().equals(\"oracle\")" "更新节点优化"

    # 检查 com.api.report.service.newCalculateEngine.CalculateTodayFlowTimeEngine.java 文件中是否含有 CalculateLastRequestTodayOperateFLowtime 即可
    # classbean/com/api/report/service/newCalculateEngine/CalculateTodayFlowTimeEngine.class
    CodeScan "CalculateTodayFlowTimeEngine" "47" "$classPath/com/api/report/service/newCalculateEngine/CalculateTodayFlowTimeEngine.class" "CalculateOverTimeRequestFlowTime extend" "流程分线程处理"
    # 找到类中private Map getFiledValue,检测通过
    CodeScan2 "RequestRemindBiz" "48" "$classPath/com/engine/workflow/biz/requestForm/RequestRemindBiz.class" "private Map getFiledValue" "流程提交慢"
    # 找到类中PoppupRemindInfoUtil,检测不通过
    CodeScan "PoppupRemindInfoUtil" "49" "$classPath/com/engine/workflow/cmd/requestForm/LoadParamCmd.class" "PoppupRemindInfoUtil" "消息提醒导致连接数高"
    # 找到类中WorkflowVersion,检测通过
    CodeScan2 "WorkflowVersion" "50" "$classPath/weaver/workflow/request/RequestOperationLogManager.class" "WorkflowVersion" "流程操作日志数据量过大"
    # 找到类中workflow_CurOpe_UpdatebyView,检测不通过
    CodeScan "workflow_CurOpe_UpdatebyView" "51" "$classPath/com/engine/workflow/biz/requestForm/RequestFormBiz.class" "workflow_CurOpe_UpdatebyView" "全员流程导致连接数高"
    # 找到类中getString("desencode"),检测通过
    CodeScan2 "desencode" "52" "$classPath/weaver/system/DocumentSecretkeyCheck.class" 'getString("desencode")' "删除密钥任务查询数据量大"
    # 找到类中public Workbook addRowExcel2007,检测通过
    CodeScan2 "addRowExcel2007" "52" "$classPath/com/cloudstore/dev/api/service/Service_DevTable.class" "public Workbook addRowExcel2007" "后端Excel统一导出数据量大"
    # 找到类中select eid,检测通过
    CodeScan2 "CommonJspUtil" "53" "$classPath/weaver/page/interfaces/commons/CommonJspUtil.class" "select eid" "CommonJspUtil门户相关请求"

    # luxiong_20230524
    # 找到类中 getTotalWorkHours 关键字,检测不通过
    CodeScan "OverTimeSetBean" "54" "$classPath/weaver/workflow/request/OverTimeSetBean.class" "getTotalWorkHours" "流程超时范围过大导致内存溢出"
    # 找到类中 public void batchAddOfsPushData 关键字,检测通过
    CodeScan2 "OfsPushDataDao" "55" "$classPath/weaver/ofs/interfaces/dao/OfsPushDataDao.class" "public void batchAddOfsPushData" "集成ofs推送导致内存溢出"
    # 找到类中 t.printStackTrace 关键字,检测不通过
    CodeScan "MailCommonUtils" "56" "$classPath/weaver/email/MailCommonUtils.class" "t.printStackTrace" "邮件死循环导致内存溢出"
    # 找到类中 listEncryptTableNames 关键字,检测通过
    CodeScan2 "EncryptFieldConfigComInfo" "57" "$classPath/com/engine/encrypt/biz/EncryptFieldConfigComInfo.class" "listEncryptTableNames" "人力数据加密缓存类导致内存溢出"
    # 找到类中 autoInitIfNotFound 关键字,检测通过
    CodeScan2 "KQGroupMemberComInfo" "58" "$classPath/com/engine/kq/biz/KQGroupMemberComInfo.class" "autoInitIfNotFound" "考勤初始化导致CPU高"
    # 找到类中 System.out.println 关键字,检测不通过
    CodeScan "LayoutFieldAttrExcute" "59" "$classPath/com/engine/cube/cmd/card/LayoutFieldAttrExcute.class" "System.out.println" "建模println输出日志过大导致系统阻塞"

    # 找到类中 t1.createdate 关键字,检测通过
    CodeScan2 "ExpXMLUtil" "60" "$classPath/weaver/expdoc/ExpXMLUtil.class" "t1.createdate" "流程归档集成导致内存溢出"
    # 找到类中 getPinyinlastname 关键字,检测通过
    CodeScan2 "RequestOperatorBiz" "61" "$classPath/com/engine/workflow/biz/requestForm/RequestOperatorBiz.class" "getPinyinlastname" "流程转发收回全体成员导致内存溢出"
    # 找到类中 getGraphics().dispose() 关键字,检测通过
    CodeScan2 "OdocFileUtil" "62" "$classPath/com/api/odoc/util/OdocFileUtil.class" "getGraphics().dispose()" "公文生成缩略图导致内存溢出"
    # 找到类中 select vsql 关键字,检测通过
    CodeScan2 "RefreshformCmd" "63" "$classPath/com/engine/cube/cmd/form/RefreshformCmd.class" "select vsql" "建模虚拟表单查询数据量过大导致内存溢出"
    # 找到类中 select fileSize from mailresourcefile 关键字,检测通过
    CodeScan2 "DocPreviewHtmlManager" "64" "$classPath/weaver/docs/docpreview/DocPreviewHtmlManager.class" "select fileSize from mailresourcefile" "文档转换导致内存溢出"
    # 找到类中 select cast 关键字,检测通过
    CodeScan2 "FormFieldTransMethod" "65" "$classPath/weaver/general/FormFieldTransMethod.class" "select cast" "流程表单编辑导致内存溢出"
    # 找到类中 size() > 200 关键字,检测通过
    CodeScan2 "wfAgentCondition" "66" "$classPath/weaver/workflow/request/wfAgentCondition.class" "size() > 200" "流程代理接收人过多导致in sql慢问题"
    # 找到类中 select detailInfo from workflow_requestoperatelog where requestid = ? and operatorid =? 关键字,检测通过
    CodeScan2 "RequestOperationMsgManager" "67" "$classPath/weaver/workflow/request/RequestOperationMsgManager.class" "select detailInfo from workflow_requestoperatelog where requestid = ? and operatorid =?" "流程自动审批发送消息导致内存溢出"
    # 找到类中 .append(",").append 关键字,检测通过
    CodeScan2 "CubeSearchTransMethod" "68" "$classPath/com/api/cube/util/CubeSearchTransMethod.class" '.append(",").append' "建模显示转换字符串拼接导致内存溢出修复"
    # 找到类中 imagefileid, filerealpath from ImageFile 关键字,检测通过
    CodeScan2 "FileBackup" "69" "$classPath/weaver/file/FileBackup.class" 'imagefileid, filerealpath from ImageFile' "附件备份功能查询结果集过大导致内存溢出"
    # 找到js中/ecology/src4js/pc4mobx/workflowForm/components/dialog/import-wf-detail/index.js 中maxUploadSize 检测通过
    JsBaseMain2 "ImportWf" "70" "src4js/pc4mobx/workflowForm/components/dialog/import-wf-detail/index.js" "maxUploadSize" "流程明细导入导致内存溢出"
    # 下述为待添加规则
    # 流程明细导入导致内存溢出
    # JVM参数优化
    # 文档预览时敏感词检测功能导致内存溢出
    # Resin等待线程过多导致服务器负载高
    # Linux操作系统最大进程数调整
    # 流程超时死锁问题
    # 文档计数并发高导致数据库连接数满

    #########20240130 by zhangxl###############
    #删除无用工作流导致数据库CPU高
    #类文件/com/weaver/procedure/wrkcrt/Wrkcrt_mutidel.class中存在"oracle".equalsIgnoreCase关键字，说明已修复
    CodeScan2 "Wrkcrt_mutidel" "201" "$classPath/com/weaver/procedure/wrkcrt/Wrkcrt_mutidel.class" '"oracle".equalsIgnoreCase' "删除无用工作流导致数据库CPU高"

    #流程导入导出数据量过大导致内存溢出
    #类文件/weaver/backup/services/ExportService.class中存在firstWriteToFile关键字，说明已修复
    CodeScan2 "ExportService" "202" "$classPath/weaver/backup/services/ExportService.class" 'firstWriteToFile' "流程导入导出数据量过大导致内存溢出"

    #优化主题图片sql查询逻辑的功能
    #类文件/weaver/file/FileDownload.class中存在DocDetail where id=? and themeshowpic=关键字，说明已修复
    CodeScan2 "FileDownload" "203" "$classPath/weaver/file/FileDownload.class" 'DocDetail where id=? and themeshowpic=' "优化主题图片sql查询逻辑的功能"

    #图片加水印导致内存溢出
    #类文件/com/engine/doc/util/WaterMarkUtil.class中存在imgAddWaterOpen关键字，说明已修复
    CodeScan2 "WaterMarkUtilimgAddWaterOpen" "204" "$classPath/com/engine/doc/util/WaterMarkUtil.class" 'imgAddWaterOpen' "图片加水印导致内存溢出"

    #流程标题查询数据量过大导致内存溢出
    #类文件/weaver/workflow/request/SetNewRequestTitle.class中存在getDbNums关键字，说明已修复
    CodeScan2 "SetNewRequestTitle" "205" "$classPath/weaver/workflow/request/SetNewRequestTitle.class" 'getDbNums' "流程标题查询数据量过大导致内存溢出"

    #连接限制问题
    #类文件/weaver/conn/DBConnectionPool.class中存在setSimultaneousBuildThrottle(20)或者setSimultaneousBuildThrottle(100)关键字，说明存在问题，检测不通过
    CodeScanE "DBConnectionPool" "206" "$classPath/weaver/conn/DBConnectionPool.class" 'setSimultaneousBuildThrottle(20)|setSimultaneousBuildThrottle(100)' "连接限制问题"

    #wps高并发请求优化
    #类文件/com/engine/doc/util/WaterMarkUtil.class中存在select max(docid) as maxdocid from docimagefile where imagefileid关键字，说明已修复问题，检测通过
    CodeScan2 "WaterMarkUtilwps" "207" "$classPath/com/engine/doc/util/WaterMarkUtil.class" 'select max(docid) as maxdocid from docimagefile where imagefileid' "wps高并发请求优化"
    #########20240130 by zhangxl###############

    #todo 211
}

#check host ip
function ip_check() {
    host=$(hostname -i 2>&1 | tr -d ": " | awk '{print $1}')
    if [ $? -ne 0 -o -z $host ]; then
        tab_mod 5 'hostnameParsing' "Parse_Error" "$(get_ip)" 'Host_ip'
    else
        tab_mod 5 'hostnameParsing' "$host" "$(get_ip)" 'Host_ip'
    fi
}
function EcodeVersion() {
    if [ -f "$oaPath"/ecode/version.json ]; then
        EcodeVersion=$(cat "$oaPath"/ecode/version.json | awk 'NR==2{print}' | awk -F ":" '{print $2}' | tr -d "\"" | tr -d "\r")
        tab_mod 37 EcodeVersion "$EcodeVersion" "1.9" "EcodeVersion"
    fi
}
function file_jdk() {
    open_files=$(ulimit -a | grep open | awk '{print $4}')
    tab_mod 6 'OpenFiles' "$open_files" 65535 'Files'

    jdk_version=$("$jdkPath"/bin/java -version 2>&1 | grep version | awk '{print $3}' | tr -d '"')
    tab_mod 7 Jdk_version "$jdk_version" '1.8+' '>1.8'
}
# 检查数据库最大连接数
function db_conn() {
    if [ -f "$oaPath"/WEB-INF/prop/weaver.properties ]; then
        maxconn=$(grep maxconn "$oaPath"/WEB-INF/prop/weaver.properties | tr -cd "[0-9]")
        tab_mod 13 DB_max_conn "$maxconn" '500' 'DB_Connections'
    else
        tab_mod 13 DB_max_conn "NotFound" '500' 'DB_Connections'
    fi

    # 检查是否开启数据库缓存
    if [ -f "$oaPath"/WEB-INF/prop/initCache.properties ]; then
        iscache=$(grep "iscache" "$oaPath"/WEB-INF/prop/initCache.properties | sed -e 's/\r//g' | grep -v "#" | grep -v 'update')
        tab_mod 14 Is_cache_check "$iscache" 'iscache=1' 'iscache=1'
    else
        tab_mod 14 Is_cache_check "NotFound" 'iscache=1' 'iscache=1'
    fi
}
function TestRedisConn() {
    # echo "$1" # arguments are accessible through name, echo "$1" # arguments are accessible through , ,...,...
    redis_result=$(timeout 5 ./redis-cli -h "$1" -p "$2" -a "$3" info 2>&1 | wc -l)

    if [ "$redis_result" -gt 5 ]; then
        # return 1
        echo 1
    else
        #    return 0
        echo 0

    fi
}
function RedisConnect() {
    redisSimple=$(grep "^redisIp*" $RedisConfPath | wc -l)
    redisCluster=$(grep "^redisCluster*" $RedisConfPath | wc -l)
    redisSentinels=$(grep "^redisSentinels=*" $RedisConfPath | wc -l)
    redis_passwd=$(grep "^redisPassword*" $RedisConfPath | awk -F '=' '{print $2}' | tr -d '\r')
    if [ $redisSimple -ne "0" ]; then
        RedisType="Simple"
        redis_host=$(grep "^redisIp*" $RedisConfPath | awk -F '=' '{print $2}' | tr -d '\r')
        redis_port=$(grep "^redisPort*" $RedisConfPath | awk -F '=' '{print $2}' | tr -d '\r')
        RedisConnResult=$(TestRedisConn $redis_host $redis_port $redis_passwd)
        if [ $RedisConnResult -eq "1" ]; then
            RedisFinResult=True
        else
            RedisFinResult=False
        fi
    elif [ $redisCluster -ne "0" ]; then
        RedisType="Cluster"
        redis_ip=$(grep "^redisCluster*" $RedisConfPath | awk -F '=' '{print $2}' | tr -d '\r')
        #要将$a分割开，先存储旧的分隔符
        OLD_IFS="$IFS"
        #设置分隔符
        IFS=","
        #如下会自动分隔
        arr=($redis_ip)
        #恢复原来的分隔符
        IFS="$OLD_IFS"
        #遍历数组
        for s in "${arr[@]}"; do
            redis_ip=$(echo $s | awk -F ":" '{print $1}')
            redis_port=$(echo $s | awk -F ":" '{print $2}')
            RedisConnResult=$(TestRedisConn $redis_ip $redis_port $redis_passwd)
            if [ "$RedisConnResult" == 0 ]; then
                RedisFinResult=False
                break
            else
                RedisFinResult=True
            fi
        done
    elif [ $redisSentinels -ne "0" ]; then
        # RedisType="Sentinels"
        redis_ip=$(grep "^redisSentinels*" $RedisConfPath | awk -F '=' '{print $2}' | tr -d '\r')
        #要将$a分割开，先存储旧的分隔符
        OLD_IFS="$IFS"
        #设置分隔符
        IFS=","
        #如下会自动分隔
        arr=($redis_ip)
        #恢复原来的分隔符
        IFS="$OLD_IFS"
        #遍历数组
        for s in "${arr[@]}"; do
            redis_ip=$(echo $s | awk -F ":" '{print $1}')
            redis_port=$(echo $s | awk -F ":" '{print $2}')
            # 1 或者 0 1连接成功 0 连接失败
            RedisConnResult=$(TestRedisConn $redis_ip $redis_port $redis_passwd)
            if [ "$RedisConnResult" == 0 ]; then
                RedisFinResult=False
                break
            else
                RedisFinResult=True
            fi
        done
    fi
    echo $RedisFinResult
}

function redis_connect() {
    # 先判断是e8还是e9

    if [ -f $oaPath/WEB-INF/prop/weaver_new_session.properties ]; then
        redisUse=$(cat $oaPath/WEB-INF/prop/weaver_new_session.properties | grep -v "^#" | grep status | awk -F "=" '{print $2}')
        if [ $redisUse == 1 ]; then
            if [ $iscluster -ge 1 ]; then
                # 集群 开始判断e8还是e9
                if [ $resinversion -eq "3" ]; then
                    #启用了redis
                    if [ "$redis_status" -eq "1" ]; then
                        tab_mod 15 redis_check "$(RedisConnect)" "True" 'Redis_conn'
                    else
                        # 未启用redis
                        tab_mod 15 redis_check "E8Cluster" "NotUseRedis" 'Redis_conn'
                    fi
                else
                    if [ "$redis_status" -eq "1" ]; then
                        tab_mod 15 redis_check "$(RedisConnect)" "True" 'Redis_conn'
                    else
                        # 未启用redis
                        tab_mod 15 redis_check "E9Cluster" "NotUseRedis" 'Redis_conn'
                    fi
                fi
            else
                #单机开始判断
                if [ $resinversion -eq "3" ]; then
                    #启用了redis
                    if [ "$redis_status" -eq "1" ]; then
                        tab_mod 15 redis_check "$(RedisConnect)" "True" 'Redis_conn'
                    else
                        # 未启用redis
                        tab_mod 15 redis_check "E8Simple" "NotUseRedis" 'Redis_conn'
                    fi
                else
                    if [ "$redis_status" -eq "1" ]; then
                        tab_mod 15 redis_check "$(RedisConnect)" "True" 'Redis_conn'
                    else
                        # 未启用redis
                        tab_mod 15 redis_check "E9Simple" "NotUseRedis" 'Redis_conn'
                    fi
                fi
            fi
        else
            tab_mod 15 redis_check "ignore" "NotUseRedis" 'Redis_conn'
        fi
    else
        tab_mod 15 redis_check "ignore" "NotUseRedis" 'Redis_conn'
    fi
}

function weaver_info() {
    if [ $redis_status -eq "1" ]; then
        if [ -f "$oaPath"/WEB-INF/web.xml ]; then
            WSession=$(grep -c WSessionClusterFilter "$oaPath"/WEB-INF/web.xml)
            tab_mod 16 WSession "${WSession:-NotFound}" '>0' 'Wsession'
        else
            tab_mod 16 WSession "Not_foundfile" 'Not_Null' 'Wsession'
        fi
    else
        tab_mod 16 WSession "NotUseRedis" '>0' 'Wsession'
    fi
    # echoGreen "==============检测web.xml是否有启动时的编译配置============="
    Precompile=$(grep "com.caucho.jsp.JspPrecompileListener" "$oaPath"/WEB-INF/web.xml)
    tab_mod 17 Precompile "${Precompile:-NotOpen}" 'Open' 'check_Precom'

    if [ -f "$oaPath/WEB-INF/prop/doc_full_search.properties" ]; then
        # echoError "$oaPath/WEB-INF/prop/doc_full_search.properties 不存在!"
        use_full_search=$(grep use_full_search "$oaPath"/WEB-INF/prop/doc_full_search.properties | sed -e 's/\r//g' | cut -d '=' -f 2)
        tab_mod 18 doc_search "$use_full_search" '1' "1-Open*-Error"

    fi
}
# echoGreen "==============检查防火墙是否开启============="
function firewall() {
    if [ $el7 -ge 7 ]; then
        firewall_status=$(systemctl status firewalld | grep "dead")
        if [[ -z ${firewall_status} ]]; then
            tab_mod 19 firewall_stat "Open" 'Dead' "Close_Firewall"
        # echoError "防火墙未关闭,请使用systemctl stop firewalld && systemctl disable firewalld关闭防火墙"
        else
            tab_mod 19 firewall_stat "Dead" 'Dead' "Close_Firewall"
        # echoGreen "防火墙检测通过"
        fi
    else
        firewall_status=$(service iptables status | grep -c "not running")
        if [ "$firewall_status" -eq "1" ]; then
            tab_mod 19 firewall_stat "Dead" 'Dead' "Close_Firewall"
        else
            tab_mod 19 firewall_stat "Open" 'Dead' "Close_Firewall"
        fi
    fi
}

function OtherWeaverService() {
    Emobile=$(ps -ef | grep -i appsvr | grep -v grep | wc -l)
    Ebridge=$(ps -ef | grep -i ebridge | grep -v grep | wc -l)
    ESearch=$(ps -ef | grep -i esearch | grep -v grep | wc -l)
    ElasticSearch=$(ps -ef | grep elasticsearch | grep -v grep | wc -l)

    tab_mod 25 Emobile "$Emobile" '0' "EmobileOn"
    tab_mod 26 Ebridge "$Ebridge" '0' "EbridgeOn"
    tab_mod 27 ESearch "$ESearch" '0' "ESearchOn"
    tab_mod 28 ElasticSearch "$ElasticSearch" '0' "ElasticSearchOn"
}
function JDKStats() {
    JDKStat=$(stat $jdkPath | head -n 4 | tail -n 1 | cut -d "/" -f 1 | tr -cd "[0-9]")
    tab_mod 30 JDKStat "$JDKStat" '0755' "JDKStat"
}
#todo 重写
function Ec_Version() {
    if [ -f $oaPath/WEB-INF/ecology.ver ]; then
        Ec_VersionNumber=$(cat $oaPath/WEB-INF/ecology.ver | tr -d ".")
        if [ $Ec_VersionNumber -lt 900200801 ]; then
            tab_mod 31 InitBug "True" 'False' "InitBug"
        else
            tab_mod 31 InitBug "False" 'False' "InitBug"
        fi
    fi

    tab_mod 43 ecVersion "$ecVersion" '9.0' "ecology_version"
    tab_mod 44 companyname "$companyName" 'Weaver' "companyname"
}

function NFSMountDumplicate() {
    NFSMountDump=$(df -hP | sort | uniq -d | wc -l)
    NFSMountDump2=$(df -TP | grep nfs | awk '{print $7}' | sort | uniq -dc | wc -l)
    tab_mod 32 NFSDump "$NFSMountDump" "0" "NFSMountDump"
    tab_mod 33 NFSDumpMount "$NFSMountDump2" "0" "NFSDumpMount"
}
function DeployDate() {
    ecology_deploy_date=$(stat "$oaPath"/WEB-INF/lib/xpp3.jar | grep Change | awk '{print $2,$3,$4}' | awk '{print $1}')
    deploy=$(date -d "$ecology_deploy_date" +%s)
    current_date=$(date +%s)
    diff=$((($current_date - $deploy) / 3600 / 24))
    if [ $diff -lt 100 ]; then
        tab_mod 38 Deploymenttime "$ecology_deploy_date" "<100" ""$diff"day_True"
    else
        tab_mod 38 Deploymenttime "$ecology_deploy_date" "<100" ""$diff"day_False"
    fi
}
function EcologyLog() {
    ecology_log_dir="$oaPath"/log
    ecology_log_size=$(du -sh $ecology_log_dir --block-size m | awk '{print $1}' | tr -d "M")
    tab_mod 34 ecology_log_size "$ecology_log_size" "<20480" "ecology_log_size"
}
function PersonaTest() {
    # 用户画像检测
    if [ -f $oaPath/WEB-INF/ecology.ver ]; then
        PersonaDBResult=$(DBTest "select runstatus from schedulesetting where desc_ like '组织画像%'")
        if [ $(echo $PersonaDBResult | awk '{print $1}') == "True" ]; then
            # 数据库连接成功
            if [ $(echo $PersonaDBResult | awk '{print $2}' | tr -cd "0-9" | grep 0 | wc -l) -gt 0 ]; then
                # 检测不通过
                tab_mod 42 "PersonaTest" "不通过" "通过" "用户画像"
            else
                tab_mod 42 "PersonaTest" "通过" "通过" "用户画像"
            fi
        else
            tab_mod 42 "PersonaTest" "数据库连接失败" "通过" "用户画像"
        fi
    fi
}
# web.xml 过滤器
function WebXmlFilter() {
    # 所有有关于web.xml的都放在这里
    WebXmlConf=$oaPath/WEB-INF/web.xml
    if [ $(grep LimitCurrFilter $WebXmlConf | wc -l) -gt 0 ]; then
        tab_mod 43 "限流包" "通过" "通过" "限流包"
    else
        tab_mod 43 "限流包" "不通过" "通过" "限流包"
    fi
    # e9限流包只针对e9
    if [ -f $oaPath/WEB-INF/ecology.ver ]; then
        if [ $(grep LoginExtensionFilter $WebXmlConf | wc -l) -gt 0 ]; then
            tab_mod 44 "E9防串号" "通过" "通过" "E9防串号"
        else
            tab_mod 44 "E9防串号" "不通过" "通过" "E9防串号"
        fi
    fi
}
# 检测安全包配置顺序
function check_web_xml_sequence() {
    echo ""
    echo '############################ web.xml过滤器顺序检测 #############################'
    xmllint -version &>/dev/null || yum install libxml2-2.9.1-6.el7.4.x86_64
    test=$(echo "cat //filter/filter-name" | xmllint --shell --noblanks "$oaPath"/WEB-INF/web.xml | grep "^<filter-name>" | sed -e 's/<filter-name>//g' | sed -e 's/<\/filter-name>//g')
    echo "$test" | tr ' ' '\n' >temp.log
    total_lines=$(wc -l temp.log | awk '{print $1}')
    dum=$(sort temp.log | uniq -dc | wc -l)
    # echo "check dumplicate!"
    if [ $dum -eq 0 ]; then
        echo 是否重复: "Not dumplicate"
    else
        dumplicate_filter_name=$(sort temp.log | uniq -dc)
        echo "FilterDumplicate!"
        echo "$dumplicate_filter_name"
    fi
    echo ""
    num=1
    WS='WSessionClusterFilter'
    SEC='SecurityFilter'
    SOC='SocialIMFilter'
    EMF='EMFilter'
    SESS='SessionCloudFilter'
    MUL='MultiLangFilter'
    WGZ='WGzipFilter'
    for i in $test; do
        if [ "$i" = "$WS" ]; then
            wsession_line=$(grep -n "WSessionClusterFilter" ./temp.log | cut -d ':' -f 1)
            wsession_line_before=$(sed -n "1,$wsession_line"p ./temp.log | grep -E 'EncodingFilterWeaver|SecurityFilter')
            if [ ! -z $wsession_line_before ]; then
                printf "%-20s  %20s\n" "$WS" check_passed
            else
                echo 'WSessionClusterFilter not in after EncodingFilterWeaver,Sequence Error'
                # exit 1
            fi
        elif [ "$i" = "$SOC" ]; then
            line_num=$(grep -n "SocialIMFilter" ./temp.log | cut -d ':' -f 1)
            # result_line=`expr $line_num - $num`
            soczip=$(sed -n "1,$line_num"p ./temp.log | grep -E 'SecurityFilter')
            if [ -z $soczip ]; then
                printf "%-20s  %20s\n" "$SOC" check_passed
            else
                echo 'SocialIMFilter not in before SecurityFilter,Sequence Error'
                # exit 1
            fi
        elif [ "$i" = "$EMF" ]; then
            line_num=$(grep -n "EMFilter" ./temp.log | cut -d ':' -f 1)
            grep_result=$(sed -n "$line_num,$total_lines"p ./temp.log | grep "SecurityFilter")
            if [ -z "$grep_result" ]; then
                echo 'Securiry not in after EMFilter'
                # exit 1
            else
                printf "%-20s  %20s\n" "$EMF" check_passed
            fi
        elif [ "$i" = $SESS ]; then
            line_num=$(grep -n "SessionCloudFilter" ./temp.log | cut -d ':' -f 1)
            grep_result=$(sed -n "$line_num,$total_lines"p ./temp.log | grep "SecurityFilter")
            if [ -z "$grep_result" ]; then
                echo 'Securiry not in after SessionCloudFilter'
                # exit 1

            else
                printf "%-20s  %20s\n" "$SESS " check_passed
            fi
        elif [ "$i" = "$MUL" ]; then
            # WGzipFilter 可能没有 多语言过滤器只要在DialogHandleFilter之前即可
            line_num=$(grep -n "MultiLangFilter" ./temp.log | cut -d ':' -f 1)
            # zip=$(sed -n "1,$line_num"p ./temp.log | grep -E 'WGzipFilter|MobileFilter' | wc -l)
            after_zip=$(sed -n "$line_num,$total_lines"p ./temp.log | grep "DialogHandleFilter" | wc -l)
            Mulexit=$(grep "MultiLangFilter" ./temp.log | wc -l)
            if [ $Mulexit -ne 0 -a $after_zip -ne 0 ]; then
                printf "%-20s  %20s\n" "$MUL" check_passed
            else
                echo 'MultiLangFilter Sequence Error Plase Check'
                # exit 1
            fi
        elif [ "$i" = "$WGZ" ]; then
            line_num=$(grep -n "WGzipFilter" ./temp.log | cut -d ':' -f 1)
            before_num=$(expr $line_num - $num)
            before_str=$(sed -n "$before_num"p ./temp.log)
            if [ "$before_str" = "$SEC" ]; then
                printf "%-20s  %20s\n" "$WGZ " check_passed
            else
                echo 'WGzipFilter Sequence Error,Please Check'
                # exit 1
            fi
        else
            printf "%-20s  %20s\n" "$i" check_passed
        fi
    done
    rm -rf $(pwd)/temp.log
}

Cluster_check() {
    echo ""
    echo '############################ ecology集群检测 #############################'
    iscluster=$(grep -c "MainControlIP" "$oaPath"/WEB-INF/prop/weaver.properties)
    if [ "$iscluster" -gt 0 ] && [ -f $oaPath/WEB-INF/ecology.ver ]; then
        if [ ! -e "$oaPath/ecologyClusterConfigCheck.jsp" ]; then
            cp ecologyClusterConfigCheck.jsp "$oaPath"
        fi
        url='http://127.0.0.1:'$port"/ecologyClusterConfigCheck.jsp"
        echo $url
        echo ""
        test=$(curl -s $url)
        # [^>]* 匹配不是>的任意字符 *代表匹配多次
        echo $test | tr -d " " | sed "s/<br>/\\n/g" | sed "s/<[^>]*>//g"
    else
        echo "非集群部署或ecology版本为E8,检查跳过!"
    fi

}

# 测试磁盘速度
function disk_speed() {
    echo ""
    echo ""
    echo "############################ Disk_Speed #############################"
    echo "This step will cost long time,please wait!"
    if [ $el7 -ge 7 ]; then
        disk=$(df -h "$oaPath" | awk '{print $1}' | grep -v Filesystem | grep -v 文件系统)
    else
        disk=$(df -h "$oaPath" | awk '{print $1}' | grep -v Filesystem | grep -v 文件系统 | awk 'NR==1{print $1}')
    fi
    disk_speed=$(hdparm -Tt "$disk" | grep Timing | awk -F "=" '{print $2 }')
    diskcache_read=$(echo "$disk_speed" | awk 'NR==1{print}' | tr -d ' ')
    diskbuffer_read=$(echo "$disk_speed" | awk 'NR==2{print}' | tr -d ' ')
    echo diskcache_read:"$diskcache_read"
    echo diskbuffer_read:"$diskbuffer_read"
}

## 连接数据库
function DBTest() {
    # 数据库配置文件
    WeaverConfigPath=$oaPath/WEB-INF/prop/weaver.properties
    if [ "$(grep "SQLServerDriver" $WeaverConfigPath | wc -l)" -gt 0 ]; then
        # dbtype="SQLServer"
        jarlist=$(find $oaPath/WEB-INF/lib/ -type f -name "sqljdbc*.jar" -size +338k)
        jarlist+=" $(find $resinPath/lib -type f -name "sqljdbc*.jar" -size +338k)"
    elif [ $(grep "mysql" $WeaverConfigPath | wc -l) -gt 0 ]; then
        jarlist=$(find $oaPath/WEB-INF/lib/ -type f -name "mysql-connector-java*.jar" -size +338k)
        jarlist+=" $(find $resinPath/lib -type f -name "mysql-connector-java*.jar" -size +338k)"
    elif [ $(grep "OracleDriver" $WeaverConfigPath | wc -l) -gt 0 ]; then
        jarlist=$(find $oaPath/WEB-INF/lib/ -type f -name "ojdbc*.jar" -size +338k)
        jarlist+=" $(find $resinPath/lib -type f -name "ojdbc*.jar" -size +338k)"
    else
        echo "False 找不到jar包"
        exit 1
    fi
    # echo $jarlist
    for i in $jarlist; do
        # 先测试
        result=$($jdkPath/bin/java -jar DBUtils.jar $i $oaPath/WEB-INF/prop/weaver.properties "$1" 2>&1)
        # 是否正常
        correct=$(echo $result | grep "数据信息" | wc -l)
        if [ $correct -gt 0 ]; then
            finalResult=$(echo $result | awk -F "==" '{print $3}' | tr -d " ")
            echo "True $finalResult"
            exit 0
            break
        fi
    done
    echo "False $result"
}

function EcodeMSGE() {
    # 2021-12-15新增
    # 云商店消息中心升级最新版本，避免导致的内存溢出问题 kb900200801
    if [ -f "$oaPath"/WEB-INF/ecology.ver ]; then
        # 获取kb版本
        kb_verison=$(cat "$oaPath"/WEB-INF/ecology.ver | tr -d ".")
        tab_mod 39 EcodeMsg "$kb_verison" ">=900200801" "EcodeMsgVersion"
    fi
}
access_secur_first() {
    url='http://127.0.0.1:'$port"/security/monitor/MonitorStatusForServer.jsp"

    # echo "This step will take a long time, please be patient."
    resutl=$(curl -s $url >test.txt)
    if [ $? != 0 ]; then
        echo 'Access Security page error,please insure the resin has been started! '
        return 0
    fi
    fin=$(grep -v '^$' test.txt | tr -d ' ' | tr -d '\r' | tr -d "\n")
    # tr -d '\r'  返回的接口信息中有回车， 需要删掉，不然解析会失败
    if [ -e dc16.jar ]; then
        if [[ -n $fin ]]; then
            returnMsg=$("$jdkPath"/bin/java -jar ./dc16.jar "$fin" "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAK2yDkw/1A946hhzvW3t4AOcsamMMnf3klqw3rZMaGWbPckzWqxl1RGtTVMoJauWZpjo+qCn3jp8RbFh6gTQE9lI61hVB/MBDKwGUq9bA5msxyDno1C5Cn0fZa6xY7BAM/JQemTtPoHo/m2y6GeXR9tjZdeIQGdb5doXA1hMvUlJAgMBAAECgYBt6j8iAUIwiFObJaK57c3Ue1Px9sX5JLF4snQ86B0oLxTqPZUjg01R4lkMRluQOZyzJrty7seyOvHfThbI9OOZkW+cnIAVq65gvj6LqnEd4upl9I+f+WmQSuBUN/Pjtx8A5PPujOXIV1g+7fL5JDfzXyfzi4banL97dSx9mxqIAQJBANu8QI9ts9EMlaoolck5O6xrACzvipwcJJbM2U2w/vQWFgjylGB4Q5wgcCGEeZRF64ovDcZxNSb4hmKqvwSVzJMCQQDKXKLCQ9BM0JpuJOckxfhYzXSvtG/vC4U/NeBNISOZiC5thoJSkyY4H27pk32rynuOxhSAQ4D/0+TDHKGIAVgzAkA2Ex3QLi8SQwaR2WsDGhKVW7+vT0PNJx/Z/I99jxEvAEBr80aQdwgsY880cGV7F7nfR7UcIL/z1zU7EsnvVu4BAkEArXHw3ukY5H33n2hp5Y75acPPu7nAJveM4bzf37wDs1iR0rZzhSsymu/2NKWCFXibpqgIcldpfdy0OreTi+r7GQJAe3vPc6J5+2JSwqCY9OSeq+MS8kAZbWMkeC4M4ai8c7BhYED/2664qCuab7v5U/VUMbhbhy+h3lq7TdjV+1xKmA==" | tr -d ' ')
            if [ $? -eq 0 ]; then
                companyName=$(parse_json "$returnMsg" "companyName")
                ecVersion=$(parse_json "$returnMsg" "ecVersion")
                export companyName=$companyName
                export ecVersion=$ecVersion
            else
                companyNameResult=$(DBTest "SELECT COMPANYNAME ,CVERSION  FROM license;")
                if [ $(echo $companyNameResult | awk '{print $1}') == "True" ]; then

                    companyName=$(echo $companyNameResult | awk '{print $2}' | tr -d '{}' | awk -F "," '{print $1}')
                    export companyName="$companyName"
                    # 8.100.0531+KB8100211000"
                    ecVersion=$(echo $companyNameResult | awk '{print $2}' | tr -d '{}' | awk -F "," '{print $2}')
                    if [ $(echo $ecVersion | grep "+" | wc -l) -gt 0 ]; then
                        ecVersion=$(echo $ecVersion | awk -F "+" '{print $2}' | tr -cd 0-9)
                        export ecVersion=$ecVersion
                    fi
                else
                    export companyName="数据库连接失败"
                fi

            fi
        else
            export companyName="NullResponse"
            export ecVersion="NullResponse"
        fi
    else
        export companyName="NullResponse"
        export ecVersion="NullResponse"
    fi
}

function doc_sensitive_words() {
    if [ -f $oaPath/WEB-INF/prop/doc_sensitive_words_config.properties ]; then
        isExistSensitive=$(cat $oaPath/WEB-INF/prop/doc_sensitive_words_config.properties | grep disable_preview_doc_check_sensitive | wc -l)
        if [ $isExistSensitive -gt 0 ]; then
            # 代表配置了这个关键字
            # 获取参数值
            isSensitive=$(grep disable_preview_doc_check_sensitive $oaPath/WEB-INF/prop/doc_sensitive_words_config.properties | awk -F "=" '{print $2}')
            if [ $isSensitive -ne 1 ]; then
                tab_mod 208 doc_sensitive_words "false" 'true' "文档预览时敏感词检测功能导致内存溢出"
            else
                tab_mod 208 doc_sensitive_words "true" 'true' "文档预览时敏感词检测功能导致内存溢出"
            fi

        else
            tab_mod 208 doc_sensitive_words "false" 'true' "文档预览时敏感词检测功能导致内存溢出"
        fi
    fi
}

function HandleTimerTask() {
    if [ -f $resinPath/bin/resin.sh ]; then
        classPath="classbean"
    else
        classPath="WEB-INF/classes"
    fi
    if [ -f $oaPath/WEB-INF/ecology.ver ]; then
        RequestFormBizDecomplieCodeHandler=$($jdkPath/bin/java -jar jd-cli.jar $oaPath/$classPath/com/engine/workflow/biz/workflowOvertime/HandleTimerTask.class|grep -A 10 'lock.lock()'|grep  '时处理加锁逻辑configKey与mapkey不一致故不执行超时'|wc -l)

        if [ $RequestFormBizDecomplieCodeHandler -gt 0 ]; then
            # 不通过
            tab_mod 209 HandleTimerTask  "false" "true" "流程超时死锁问题"
        else
            #找到关键字,检测不通过
            tab_mod 209 HandleTimerTask  "true" "true" "流程超时死锁问题"
        fi
    fi
}

function docpreview() {
    if [ -f $oaPath/WEB-INF/prop/docpreview.properties ]; then
        isExistSensitive=$(cat $oaPath/WEB-INF/prop/docpreview.properties | grep resizeCountOpen | wc -l)
        if [ $isExistSensitive -gt 0 ]; then
            # 代表配置了这个关键字
            # 获取参数值
            isSensitive=$(grep resizeCountOpen $oaPath/WEB-INF/prop/docpreview.properties | awk -F "=" '{print $2}')
            if [ $isSensitive -ne 0 ]; then
                tab_mod 210 resizeCountOpen "false" 'true' "文档计数并发高导致数据库连接数满"
            else
                tab_mod 210 resizeCountOpen "true" 'true' "文档计数并发高导致数据库连接数满"
            fi

        else
            tab_mod 210 resizeCountOpen "false" 'true' "文档计数并发高导致数据库连接数满"
        fi
    fi
}

function ecology_WEBINF_prop_exceeds10mb() {
    # 扫描\ecology\WEB-INF\prop目录下所有的配置文件，大小超过10m的文件都提示需要检查是否有异常(prop下的都是配置文件，理论上都是很小的，文件很大基本上都是出现了异常，大文件加载会占用较大内存，导致内存溢出)

    _ecology_prop_dir="$oaPath"/WEB-INF/prop
    _ecology_prop_exceeds10mb_num=$(find $_ecology_prop_dir  -size +10M | wc -l )

    tab_mod 302 ecology_prop_exceeds10mb_num "$_ecology_prop_exceeds10mb_num" "0" "prop目录下大小超过10m的配置文件数量"
}