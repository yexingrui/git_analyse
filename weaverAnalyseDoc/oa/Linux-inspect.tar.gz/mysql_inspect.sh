#!/bin/bash
#---------------------------------------------------------------------------
# File: mysql_inspect.sh
# Created Date: 2020-12-31
# Author: sunzhe
# Contact: <sunzhenet@163.com>
#
# Last Modified: Wednesday June 8th 2022 5:36:03 pm
#
# Copyright (c) 2020 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
#!/bin/bash
#ecology system check
# export LANG=zh_CN.gbk
export LANG=en_US.utf8
export LC_ALL=en_US.utf8
# 获取脚本所在绝对路径
SHELL_FOLDER=$(
    cd "$(dirname "$0")"
    pwd
)
# 定义基本表格
tab_top() {
    echo -n -e "+-------------------------------------------------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| ID \| Item \| Value \|
}
tab_mod() {
    echo -n -e "+----------+---------------------------+----------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| "$1" \| "$2" \| "$3" \|
}
tab_end() {
    echo -n -e "+-------------------------------------------------------------------+\n"
}
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh
function log_gen() {
    IPADDR="$(get_ip)"
    RESULTFILE="MYSQL_Inspection-$IPADDR-$(date +%Y%m%d%H%M).txt"
    # echo $RESULTFILE
}

###########check IP addr###########

export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
source /etc/profile
# mysql数据库巡检
function mysql_query() {
    result=$($mysql_path -u$mysql_user -P$mysql_port -h$mysql_host -p$mysql_passwd -e "SHOW VARIABLES WHERE variable_name in ('"$1"')" 2>/dev/null | awk '{print $2}' | tail -n 1)
    echo $result
    # echo "$1" # arguments are accessible through $1, $2,...
}

function mysql_inspect() {
    # get mysql parameter
    # mysql host default localhost
    read -p "please input the mysql host,default localhost :" mysql_host_input
    # echo $mysql_host_input
    mysql_host=${mysql_host_input:-"localhost"}
    # echo $mysql_host

    # mysql user default root
    read -p "please input the mysql user,default root :" mysql_user_input
    mysql_user=${mysql_user_input:-"root"}
    # echo $mysql_user_input
    # mysql user passwd
    read -p "please input the mysql user passwd:" mysql_passwd

    # mysql port
    read -p "Please input the mysql port default 3306:" mysql_port_input
    mysql_port=${mysql_port_input:-"3306"}
    command -v mysql
    if [ $? -ne 0 ]; then
        read -p "please input the mysql installdir such as /usr/local/mysql/bin/mysql :" mysql_path
    else
        mysql_path="mysql"
    fi
    # 检测mysql是否可以正常链接
    $mysql_path -u$mysql_user -P$mysql_port -h$mysql_host -p$mysql_passwd -e "select version()"
    if [ $? -ne 0 ]; then
        echoError "MySQL链接失败,请重新输入mysql用户账号密码"

        exit 1
    fi
    echo "############################ 数据库参数 #############################"
    echo ""
    declare -A dict
    dict['log_bin_trust_function_creators']=$(mysql_query log_bin_trust_function_creators)
    dict['transaction_isolation']=$(mysql_query transaction_isolation)
    dict['lower_case_table_names']=$(mysql_query lower_case_table_names)
    dict['sql_mode']=$(mysql_query sql_mode)
    dict['innodb_large_prefix']=$(mysql_query innodb_large_prefix)
    dict['group_concat_max_len']=$(mysql_query group_concat_max_len)
    dict['binlog_format']=$(mysql_query binlog_format)
    dict['log_bin']=$(mysql_query log_bin)
    dict['expire_logs_days']=$(mysql_query expire_logs_days)
    dict['max_allowed_packet']=$(mysql_query max_allowed_packet)
    dict['slow_query_log']=$(mysql_query slow_query_log)
    dict['innodb_buffer_pool_size']=$(mysql_query innodb_buffer_pool_size)
    dict['innodb_buffer_pool_instances']=$(mysql_query innodb_buffer_pool_instances)
    dict['innodb_thread_concurrency']=$(mysql_query innodb_thread_concurrency)
    dict['sync_binlog']=$(mysql_query sync_binlog)
    dict['innodb_flush_log_at_trx_commit']=$(mysql_query innodb_flush_log_at_trx_commit)
    dict['max_connections']=$(mysql_query max_connections)
    tab_top
    i=1
    for key in ${!dict[*]}; do
        tab_mod $i "$key" "${dict[$key]}" "$key"
        ((i++))
        # echo "$key:${dict[$key]}"
    done
    tab_end
}
function main() {
    mysql_inspect
    check
}
log_gen
main | tee "$RESULTFILE"
