#!/bin/bash
#---------------------------------------------------------------------------
# File: nginx_inspect.sh
# Created Date: 2021-04-20
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# 
# Last Modified: Thursday August 26th 2021 2:08:34 pm
# 
# Copyright (c) 2021 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
# 获取脚本所在绝对路径
SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh
function log_gen() {
    IPADDR="$(get_ip)"
    RESULTFILE="Nginx_Inspection-$IPADDR-$(date +%Y%m%d%H%M).txt"
    # echo $RESULTFILE
}
tab_top() {
    echo -n -e "+-------------------------------------------------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| ID \| Item \| Value \|
}
tab_mod() {
    echo -n -e "+----------+---------------------------+----------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| "$1" \| "$2" \| "$3" \|
}
tab_end() {
    echo -n -e "+-------------------------------------------------------------------+\n"
}

# 获取nginx
function nginx_client_maxbody () {
    NginxExists=$( ps -ef |grep nginx| grep -v grep |grep  -c master  )
    if [ "$NginxExists" -gt 0 ];then
        # 开始查找nginx配置文件获取pid
        Nginx_exe=$(ls -l  /proc/$(ps -ef | grep nginx  | grep master  |awk '{ print $2}')/exe  | awk  -F ">" '{ print $2}' | tr -d " ")
        # echo $Nginx_exe
        ConfDir=$($Nginx_exe  -t 2>&1 |awk 'NR==1' | awk -F " "  '{print $5}' )
        # echo "$ConfDir"
        # echo "$Nginx_exe"
        export ConfDir
        export Nginx_exe
    else
        read -rp "please enter the nginx bin path such as /opt/nginx/sbin/nginx: " ConfDirInput 
        if [ -e "$ConfDirInput" ];then
            ConfDir=$($ConfDirInput  -t 2>&1 |awk 'NR==1' | awk -F " "  '{print $5}' )
            # echo "$ConfDir"
            # echo "$Nginx_exe"
            export ConfDir
            export Nginx_exe
        else
            echoError "input error,please retry"
            exit 0
        fi
    fi
}
function Nginx () {

    nginx_client_maxbody
    tab_top
    # 获取nginx版本
    declare -A dict
    dict['Nginx_version']=$("$Nginx_exe" -v 2>&1 |awk -F ":" '{print $2}' | tr -d " ")
    dict['Nginx_process']=$(ps -ef |grep -v grep | grep process | grep -c nginx)
    dict['Nginx_connections']=$(netstat -apn|grep -c 'nginx: worker')
    nginx_error_log_file_Shell=$( grep -v "#" "$ConfDir" | grep -v "^$" | grep  error_log|awk 'NR==1{print}'| awk '{print $2}')
    nginx_error_log_file=${nginx_error_log_file_Shell:-"/var/log/nginx/error.log"}
    
    TIME=$(date -d "10 minute ago" +"%Y/%m/%d %H:%M")
    # dict['Nginx_error_count']=$(grep -c "$TIME" "$nginx_error_log_file")
    Nginx_worker_processes=$(grep -v "#"  "$ConfDir"  |  grep -v "^$" | grep worker_processes |tr -cd '0-9')
    dict['Nginx_worker_processes']=${Nginx_worker_processes:-"NotConfig"}
    dict['worker_connections']=$(grep -v "#"  "$ConfDir" | grep -v "^$" | grep worker_connections |tr -cd '0-9')
    
    UseEpoll=$(grep -v "#"  "$ConfDir"  | grep -v "^$" | grep  "use epoll"|awk '{print $2}' | tr -d ";"|tr -d '\r\n')
    dict['UseEpoll']=${UseEpoll:-"NotConfig"}
    
    server_tokens=$(grep -v "#"  "$ConfDir"  | grep -v "^$" |  grep  "server_tokens"|awk '{print $2}' | tr -d ";"|tr -d '\r\n' )
    dict['server_tokens']=${server_tokens:-"NotConfig"}

    # 只取第一个
    client_max_body_size_exist=$(grep -v "#"  "$ConfDir" | grep -v "^$" | grep  "client_max_body_size"|awk 'NR==1{print}'|awk '{print $2}' | tr -d ";"|tr -d '\r\n' )
    dict['client_max_body_size']=${client_max_body_size_exist:-"NotConfig"}
    # 
    client_body_buffer_size=$(grep -v "#" "$ConfDir"  | grep -v "^$" |  grep  "client_body_buffer_size"|awk '{print $2}' | tr -d ";" |tr -d '\r\n')
    dict['client_body_buffer_size']=${client_body_buffer_size:-"NotConfig" }
    
    multi_accept=$(grep -v "#" "$ConfDir"  | grep -v "^$" |  grep  "multi_accept"|awk '{print $2}' | tr -d ";" |tr -d '\r\n' )
    dict['multi_accept']=${multi_accept:-"NotConfig"}
    
    worker_cpu_affinity=$(grep -v "#" "$ConfDir" | grep -v "^$" |  grep  "worker_cpu_affinity"|awk '{print $2}' | tr -d ";" |tr -d '\r\n'  )
    dict['worker_cpu_affinity']=${worker_cpu_affinity:-"NotConfig"}

    
    keepalive_timeout=$(grep -v "#" "$ConfDir"   | grep -v "^$" |  grep  "keepalive_timeout"|awk '{print $2}' | tr -d ";" |tr -d '\r\n')
    dict['keepalive_timeout']=${keepalive_timeout:-"NotConfig"}

    #TODO,accesslog日志判断标准未确定，可能存在 1、多个nginx子配置文件 2、多个server段 3、自定义access.log日志的情况，暂注释
    #access_log=$(grep -v "#" "$ConfDir"   | grep -v "^$" |  grep  "access_log"|awk '{print $2,$3}' | tr -d ";" |tr -d '\r\n')
    #dict['access_log']=${access_log:-"NotConfig"}

    dict['UseSSL']=$(grep -v "#" "$ConfDir"   | grep -v "^$" |  grep -c "ssl_certificate")
    UseSSL=$(grep -v "#" "$ConfDir"   | grep -v "^$" |  grep -c "ssl_certificate")
    if [ "$UseSSL" -gt 0 ];then
        dict['proxy_redirect']=$(grep -v "#" "$ConfDir"   | grep -v "^$" |  grep  "proxy_redirect"|awk 'NR==1{print}'| awk '{print $2,$NF}' | tr -d ";" |tr -d '\r\n')
    else
        dict['proxy_redirect']="NotUseSSL"
    fi
    proxy_read_timeout=$(grep -v "#" "$ConfDir"   | grep -v "^$" |  grep  "proxy_read_timeout"|awk 'NR==1{print}'|awk '{print $2}' | tr -d ";" |tr -d '\r\n')
    if [ -z "$proxy_read_timeout" ];then
        dict['proxy_read_timeout']="NotConfig"
    else
        dict['proxy_read_timeout']="$proxy_read_timeout"
    fi
    proxy_send_timeout=$(grep -v "#" "$ConfDir"   | grep -v "^$" |  grep  "proxy_send_timeout"|awk 'NR==1{print}'|awk '{print $2}' | tr -d ";" |tr -d '\r\n')
    if [ -z "$proxy_send_timeout" ];then
        dict['proxy_send_timeout']="NotConfig"
    else
        dict['proxy_send_timeout']="$proxy_read_timeout"
    fi
    i=1
    for key in ${!dict[*]}
    do
        tab_mod $i "$key" "${dict[$key]}" "$key"
        (( i++ ))
        # echo "$key:${dict[$key]}"
    done
    tab_end
}
function main () {
    Nginx
    check 
}
log_gen
main| tee "$RESULTFILE"

