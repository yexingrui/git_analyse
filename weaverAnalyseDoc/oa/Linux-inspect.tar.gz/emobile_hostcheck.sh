#!/bin/bash
#---------------------------------------------------------------------------
# File: hostcheck.sh
# Created Date: 2020-12-14
# Author: sunzhe
# Contact: <sunzhenet@163.com>
#
# Last Modified: Wednesday April 27th 2022 10:12:08 am
#
# Copyright (c) 2020 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------

#!/bin/bash
#ecology system check
export LANG=en_US.utf8
export LC_ALL=en_US.utf8
# 获取脚本所在绝对路径
SHELL_FOLDER=$(
    cd "$(dirname "$0")"
    pwd
)
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh
function log_gen() {
    IPADDR="$(get_ip)"
    RESULTFILE="EMP_Inspection-$IPADDR-$(date +%Y%m%d%H%M).txt"
    # echo $RESULTFILE
}
tab_top() {
    echo -n -e "+-------------------------------------------------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| ID \| Item \| Value \|
}
tab_mod() {
    echo -n -e "+----------+---------------------------+----------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| "$1" \| "$2" \| "$3" \|
}
tab_end() {
    echo -n -e "+-------------------------------------------------------------------+\n"
}

function getpath() {
    # echo ""
    read -p "please enter the emp path(default /usr/emp): " i_empPath
    empPath=${i_empPath:-"/usr/emp"}

    if [ ! -d $empPath/appsvr ]; then
        # clear
        echoError "The Path the you input is Error,please retry!"
        getpath
    fi
}
function mysql_check() {
    echo ""
    echo ""
    echo "############################ MySQL #############################"
    # Getdatabase driver
    driver=$(grep ^spring.datasource.driver-class-name $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}' | tr -d '\r')
    if [ $driver != "com.mysql.cj.jdbc.Driver" ]; then
        tab_mod 1 MySQLConnect NotMySQL
        tab_end
        return 0
    fi
    #    mysql_connect_str=$(grep ^spring.datasource.url $config_path/work/config/application-custom.properties | awk -F "="  '{print $2}' )
    mysql_host=$(grep ^spring.datasource.url $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}' | awk -F "//" '{print $2}' | awk -F ":" '{print $1}')
    mysql_port=$(grep ^spring.datasource.url $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}' | awk -F "//" '{print $2}' | awk -F ":" '{print $2}' | awk -F "/" '{print $1}')
    mysql_db=$(grep ^spring.datasource.url $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}' | awk -F "//" '{print $2}' | awk -F ":" '{print $2}' | awk -F "/" '{print $2}' | awk -F "?" '{ print $1}')
    mysql_user=$(grep ^spring.datasource.username $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}')
    mysql_exec_dir="$empPath/dbsvr/mysql/bin/mysql"
    # 判断密码 如果主机ip是127则为默认密码 如果不是 则取spring.datasource.password
    if [ $mysql_host == "127.0.0.1" ]; then
        mysql_passwd='WEAVERemobile7!@#'
    else
        mysql_passwd=$(grep ^spring.datasource.password $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}')
    fi
    mysql_connect_test=$($mysql_exec_dir -h"$mysql_host" -P"$mysql_port" -uroot -p"$mysql_passwd" -e "show databases;" 2>&1 >/dev/null)
    if [ $? -eq 0 ]; then
        tab_mod 1 MySQLConnect True
        tab_end
    else
        tab_mod 1 MySQLConnect False
        tab_end
    fi
    
    if [ -f $empPath/start.sh ] && [ $(cat $empPath/start.sh | grep -v "^#" | grep "service \${MYSQL_SERVICE_NAME} start" | wc -l) -gt 0 ] && [ ! -f $empPath/noservice_start.sh ]; then
        mysql_logdir=$(ls -l "$empPath/work/logs/mysqllog/mysqlerr.log" | awk '{print $3}')
        if [ $mysql_logdir == "mysql" ]; then
            tab_mod 2 MySQLLogOwn mysql
            tab_end
            # echo "The owner is mysql check Passed"
        else
            tab_mod 2 MySQLLogOwn "$mysql_logdir"
            tab_end
        fi
    fi
}

function ConnectRedis() {
    redis_status=$(timeout 5 ./redis-cli -h "$redis_host" -a "$redis_passwd" -p "$redis_port" info | wc -l)
    tab_top
    if [ "$redis_status" -lt 5 ]; then
        tab_mod 1 RedisConnect Error
        tab_end
        # exit 0
        return 0
    fi

    timeout 5 ./redis-cli -h "$redis_host" -a "$redis_passwd" -p "$redis_port" info >redisinfo.txt 2>&1
    declare -A dict
    dict['redis_version']=$(cat <redisinfo.txt | grep redis_version | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_mode']=$(cat <redisinfo.txt | grep redis_mode | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_port']=$(cat <redisinfo.txt | grep tcp_port | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_exec']=$(cat <redisinfo.txt | grep executable | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_conf']=$(cat <redisinfo.txt | grep config_file | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_connect_client']=$(cat <redisinfo.txt | grep connected_clients | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['blocked_clients']=$(cat <redisinfo.txt | grep blocked_clients | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_used_mem']=$(cat <redisinfo.txt | grep used_memory_human | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_total_mem']=$(cat <redisinfo.txt | grep total_system_memory_human | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['redis_maxmem']=$(cat <redisinfo.txt | grep maxmemory_human | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['rdb_last_bgsave_status']=$(cat <redisinfo.txt | grep rdb_last_bgsave_status | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['aof_enabled']=$(cat <redisinfo.txt | grep aof_enabled | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['rejected_connections']=$(cat <redisinfo.txt | grep rejected_connections | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['connected_slave']=$(cat <redisinfo.txt | grep connected_slave | awk -F ":" '{ print $2}' | tr -d "\r")
    dict['mem_fragmentation_ratio']=$(cat <redisinfo.txt | grep mem_fragmentation_ratio | awk -F ":" '{ print $2}' | tr -d "\r")

    # redisconf 检测
    redisconfPath=$(cat <redisinfo.txt | grep config_file | awk -F ":" '{ print $2}' | tr -d "\r")
    maxcli=$(cat <"$redisconfPath" | grep '^[^#]' | grep maxclients | awk '{ print $2}' | tr -d "\r")
    if [ -z "$maxcli" ]; then
        dict['maxclients']="10000"
    else
        dict['maxclients']=$maxcli
    fi
    # 缓存命中率
    keyspace_hits=$(cat <redisinfo.txt | grep keyspace_hits | awk -F ":" '{ print $2}' | tr -d "\r")
    keyspace_misses=$(cat <redisinfo.txt | grep keyspace_misses | awk -F ":" '{ print $2}' | tr -d "\r")
    # keyspace_hits=10000
    # keyspace_misses=2342543
    # echo $keyspace_hits
    # echo $keyspace_misses
    if [ "$keyspace_hits" -eq 0 ] || [ "$keyspace_misses" -eq 0 ]; then
        dict['Cache_hit_ratio']="0%"
    else
        dict['Cache_hit_ratio']="$(echo "$keyspace_hits" "$keyspace_misses" | awk '{printf ("%.2f\n",$1/($1+$2)*100)}')%"
    fi
    i=1
    for key in $(echo ${!dict[*]}); do
        tab_mod $i $key ${dict[$key]} $key
        let i++
        # echo "$key:${dict[$key]}"
    done
    tab_end
}

function redis_check() {
    echo ""
    echo ""
    echo "############################ Redis #############################"
    redis_port=$(grep ^spring.redis.port $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}' | tr -d '\r')
    redis_host=$(grep ^spring.redis.host $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}' | tr -d '\r')
    redis_passwd=$(grep ^spring.redis.password $empPath/work/config/application-custom.properties | awk -F "=" '{print $2}' | tr -d '\r')
    ConnectRedis $redis_host $redis_port $redis_passwd
}
function EmpCrashLog() {
    echo ""
    echo ""
    echo "############################ EmpCrashLog #############################"
    tab_top
    WebXmlConf=$empPath/appsvr/tomcat/webapps/ROOT/WEB-INF/web.xml
    MonitorServer=$(grep -ci "weaver.general.MonitorServer" $WebXmlConf)
    if [ $MonitorServer -eq 0 ]; then
        tab_mod 1 "EmpCrashLogForMonitor" "False"
        # tab_end
        # echoError "EmpCrashLog config for monitor  check error,please config the EmpCrashLog"
    else
        tab_mod 1 "EmpCrashLogForMonitor" "True"

        # echo "EmpCrashLog config for monitor check Passed!"
    fi
    if [ -e $empPath/jdk ]; then
        emp_deploy_date=$(stat "$empPath"/jdk/README.html | grep Change | awk '{print $2,$3,$4}')
        deploy=$(date -d "$emp_deploy_date" +%s)
        current_date=$(date +%s)
        diff=$((($current_date - $deploy) / 3600 / 24))
        if [ $diff -lt 100 ]; then
            tab_mod 2 系统部署时间 "$diff天_部署天数通过"
        else
            tab_mod 2 系统部署时间 "$diff天_部署天数不通过"
        fi
    else
        tab_mod 2 系统部署时间 "JDK_NotFound"
    fi
    EmpVersionConfig="$empPath/appsvr/tomcat/webapps/ROOT/WEB-INF/classes/config/application-version.properties"
    EmpVersion=$(cat $EmpVersionConfig | grep emobile.version | awk -F "=" '{print $2}' | tr -cd "0-9")
    tab_mod 3 "系统版本" "$EmpVersion"
    # tomcat content.xml
    ResourcesConfig=$(grep cacheMaxSize $empPath/appsvr/tomcat/conf/context.xml | wc -l)
    if [ "$ResourcesConfig" -gt 0 ]; then
        tab_mod 4 "TomcatCache" "True"
    else
        tab_mod 4 "TomcatCache" "False"
    fi
    tab_end
}

function main() {
    getpath
    mysql_check
    redis_check
    EmpCrashLog
    check
}
log_gen
main | tee "$RESULTFILE"
