#!/bin/bash
#---------------------------------------------------------------------------
# File: hostcheck.sh
# Created Date: 2020-11-26
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# 
# Last Modified: Thursday July 7th 2022 5:14:25 pm
# 
# Copyright (c) 2020 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
#!/bin/bash
#ecology system check
# export LANG=zh_CN.gbk
export LANG=en_US.utf8
export LC_ALL=en_US.utf8
# 获取脚本所在绝对路径
SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh


export PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
source /etc/profile
  


#日志相关
IPADDR="$(ip route show |sed -n '/src/p' |grep -v docker| sed -e 's/  */ /g'|cut -d ' ' -f9|sed -n '1p')"

RESULTFILE="Oracle_Inspection-$IPADDR-`date +%Y%m%d`.txt"
  

function oracle_check(){
    \cp "$SHELL_FOLDER"/check_oracle.sql /tmp
    chmod 777 /tmp/check_oracle.sql
    read -rp '请输入OA用户名，默认为ecology:' db
    db_name=${db:-"ecology"}
    su - oracle -c "
export NLS_LANG='SIMPLIFIED CHINESE_CHINA.AL32UTF8'
sqlplus / as sysdba <<EOF
set line 4000;
@/tmp/check_oracle.sql $db_name
exit
EOF"

}  


function main () {
    oracle_check
    check
}


#执行检查并保存检查结果
main |tee $RESULTFILE

  
# echo "检查结果：$RESULTFILE"
# echo ''





