#!/bin/bash

SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh

function log_gen() {
    IPADDR="$(get_ip)"
    SimpleRESULTFILE="SimpleHost_Inspection-$IPADDR-$(date +%Y%m%d%H%M).txt"
    # echo $RESULTFILE
}


log_gen
check | tee "$SimpleRESULTFILE"
echo "检查结果：$SimpleRESULTFILE"
echo ''