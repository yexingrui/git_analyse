#!/bin/bash
#---------------------------------------------------------------------------
# File: redischeck.sh
# Created Date: 2021-04-16
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# 
# Last Modified: Friday June 10th 2022 10:55:42 am
# 
# Copyright (c) 2021 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
#需要redis端口 密码



#ecology system check
export LANG=en_US.utf8
export LC_ALL=en_US.utf8
SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh
function log_gen() {
    IPADDR="$(get_ip)"
    RESULTFILE="NFS_Inspection-$IPADDR-$(date +%Y%m%d%H%M).txt"
    # echo $RESULTFILE
}
echoError() { echo -e $"\e[43;31;5m  "$1"\e[0m"; }
[ "$(id -u)" -gt 0 ] && echo "请用root用户执行此脚本！" && exit 1
# if [ ! -f /etc/redhat-release ]; then
#     echo "Sorry,This Script does't support not redhat series system!"
# fi
el7=$( cat  < /etc/redhat-release | tr -cd "0-9" | cut -c 1)


tab_top() {
    echo -n -e "+-------------------------------------------------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| ID \| Item \| Value \|
}
tab_mod() {
    echo -n -e "+----------+---------------------------+----------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| "$1" \| "$2" \| "$3" \|
}
tab_end() {
    echo -n -e "+-------------------------------------------------------------------+\n"
}
echoError() { echo -e $"\e[43;31;5m  "$1"\e[0m"; }
[ "$(id -u)" -gt 0 ] && echo "请用root用户执行此脚本！" && exit 1
# if [ ! -f /etc/redhat-release ]; then
#     echo "Sorry,This Script does't support not redhat series system!"
# fi
el7=$( cat  < /etc/redhat-release | tr -cd "0-9" | cut -c 1)
# 判断是否为nfs主机
NFS_Process=$(ps -ef |grep nfsd|grep -v grep |wc -l)
if [ $NFS_Process -eq 0 ]; then
    echoError "未找到NFS进程,请确保NFS已启动!"
    exit 0
fi
function NFS_Inspection () {
    declare -A dict
    # NFS版本 
    dict['NFS_Version']=$(rpm -q nfs-utils)
    # 开机自启
    if [ $el7 -eq 7 ]; then
        dict['AutoStart']=$(systemctl list-unit-files |grep nfs.service|awk '{print $2}')
        # 结果为enabled 或disabled
    else
        dict['AutoStart']=$(chkconfig --list nfs|awk '{print $5}'|awk -F ":" '{print $2}')
        # 结果为ON或OFF
    fi
    # 配置参数
    dict['configurationParameter']=$(cat /etc/exports|awk -F "(" '{print $2}'|tr -d ')'|awk 'NR==1{print}')
    # 共享目录是否充足
    shareDir=$(cat /etc/exports|awk '{print $1}')
    dict['diskOccupancy']=$(df -hP "$shareDir" | awk '{print $5}' | awk 'NR==2{print}')
    i=1
    for key in $(echo ${!dict[*]})
    do
        tab_mod $i $key ${dict[$key]} $key
        let i++
        # echo "$key:${dict[$key]}"
    done
    tab_end
}

function main () {
    NFS_Inspection
    check 
}
log_gen
main| tee "$RESULTFILE"






