#!/bin/bash
#---------------------------------------------------------------------------
# File: redischeck.sh
# Created Date: 2021-04-16
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# 
# Last Modified: Tuesday May 17th 2022 2:20:20 pm
# 
# Copyright (c) 2021 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
#需要redis端口 密码



#ecology system check
export LANG=en_US.utf8
export LC_ALL=en_US.utf8
SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh
function log_gen() {
    IPADDR="$(get_ip)"
    RESULTFILE="Redis_Inspection-$IPADDR-$(date +%Y%m%d%H%M).txt"
    # echo $RESULTFILE
}


  

tab_top() {
    echo -n -e "+-------------------------------------------------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| ID \| Item \| Value \|
}
tab_mod() {
    echo -n -e "+----------+---------------------------+----------------------------+\n"
    printf "%-1s %-8s %-1s %-25s %-1s %-26s %-1s \n" \| "$1" \| "$2" \| "$3" \|
}
tab_end() {
    echo -n -e "+-------------------------------------------------------------------+\n"
}
function redis_check() {
    redis-cli --version &>/dev/null
    if [ $? -ne 0 ]; then
        if [ -f ./redis-cli ]; then
            chmod +x ./redis-cli
            ln -s "$PWD"/redis-cli /bin/redis-cli
        else
            echoError "Please upload redis-cli to current directory"
            exit 1
        fi
    fi
}
function ConnectRedis () {
    redis_check
    redis_status=$(timeout 5 redis-cli  -a "$redis_passwd" -p "$redis_port" info | wc -l)
    
    if [ "$redis_status" -lt 5 ]; then
        echoError "Redis connect Error,please retry"
        exit 0
    fi
    tab_top
    timeout 5 redis-cli  -a "$redis_passwd" -p "$redis_port" info > redisinfo.txt 2>&1
    declare -A dict
    dict['redis_version']=$(cat < redisinfo.txt | grep redis_version|awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_mode']=$(cat < redisinfo.txt | grep redis_mode|awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_port']=$(cat < redisinfo.txt | grep tcp_port|awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_exec']=$(cat < redisinfo.txt | grep executable|awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_conf']=$(cat < redisinfo.txt | grep config_file|awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_connect_client']=$(cat < redisinfo.txt | grep connected_clients|awk -F ":" '{ print $2}'|tr -d "\r")
    dict['blocked_clients']=$(cat < redisinfo.txt | grep blocked_clients |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_used_mem']=$(cat < redisinfo.txt | grep used_memory_human |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_total_mem']=$(cat < redisinfo.txt | grep total_system_memory_human |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['redis_maxmem']=$(cat < redisinfo.txt | grep maxmemory_human |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['rdb_last_bgsave_status']=$(cat < redisinfo.txt | grep rdb_last_bgsave_status |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['aof_enabled']=$(cat < redisinfo.txt | grep aof_enabled |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['rejected_connections']=$(cat < redisinfo.txt | grep rejected_connections |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['connected_slave']=$(cat < redisinfo.txt | grep connected_slave |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['mem_fragmentation_ratio']=$(cat < redisinfo.txt | grep mem_fragmentation_ratio |awk -F ":" '{ print $2}'|tr -d "\r")
    dict['maxmemory_policy']=$(cat < redisinfo.txt | grep maxmemory_policy |awk -F ":" '{ print $2}'|tr -d "\r")

    # redisconf 检测
    redisconfPath=$(cat < redisinfo.txt | grep config_file|awk -F ":" '{ print $2}'|tr -d "\r")
    maxcli=$(cat < "$redisconfPath" | grep '^[^#]' |grep maxclients | awk  '{ print $2}'|tr -d "\r")
    if [ -z "$maxcli" ]; then
        dict['maxclients']="10000"
    else
        dict['maxclients']=$maxcli
    fi
    # 缓存命中率
    keyspace_hits=$(cat < redisinfo.txt | grep keyspace_hits |awk -F ":" '{ print $2}'|tr -d "\r")
    keyspace_misses=$(cat < redisinfo.txt | grep keyspace_misses |awk -F ":" '{ print $2}'|tr -d "\r")
    # keyspace_hits=10000
    # keyspace_misses=2342543
    # echo $keyspace_hits
    # echo $keyspace_misses
    if [ "$keyspace_hits" -eq 0 ] || [ "$keyspace_misses" -eq 0 ];then
        dict['Cache_hit_ratio']="0%"
    else
        dict['Cache_hit_ratio']="$(echo "$keyspace_hits" "$keyspace_misses" | awk '{printf ("%.2f\n",$1/($1+$2)*100)}')%"
    fi
    i=1
    for key in $(echo ${!dict[*]})
    do
        tab_mod $i $key ${dict[$key]} $key
        let i++
        # echo "$key:${dict[$key]}"
    done
    tab_end
}

function getpath () {
    # echo ""
    redis_exist=$(ps -aux |grep redis-server |grep -v grep | wc -l)
    if [ "$redis_exist" -eq 0 ];then
        echoError "未找到redis进程，请确保redis已启动"
        exit 0
    else
        # 不能用pgrep  centos6 不支持pgrep -a选项
        redis_suggest_port=$(ps -ef | grep redis-server | grep -v grep|  grep -o ':\<[[:digit:]]\{4,5\}\>' |awk 'NR==1{print}' | tr -cd '0-9')
        # grep -o 只显示匹配到的字符
        # ':\<[[:digit:]]\{4,5\}\>' 匹配 : 后面跟4位到5位数字
    fi
    #推荐redis port可能为空
    if [ -z "$redis_suggest_port" ]; then
        # read 不带r会忽略\斜杠
        read -rp "please enter the redis port (default 6379): " i_port
        redis_port=${i_port:-"6379"}
    else
        read -rp "please enter the redis port (default $redis_suggest_port): " i_port
        redis_port=${i_port:-"$redis_suggest_port"}
    fi
    read -rp "please enter the redis passwd (default 123456): " i_passwd
    
    redis_passwd=${i_passwd:-"123456"}
    
    ConnectRedis

}

function main () {
    getpath
    check 
}
log_gen
main| tee "$RESULTFILE"






