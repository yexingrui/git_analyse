#!/bin/bash
#---------------------------------------------------------------------------
# File: getCollection.sh
# Created Date: 2021-01-15
# Author: sunzhe
# Contact: <sunzhenet@163.com>
#
# Last Modified: Friday June 2nd 2023 11:32:44 am
#
# Copyright (c) 2021 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
#!/bin/bash
#ecology system check
# 获取脚本所在绝对路径
SHELL_FOLDER=$(
    cd "$(dirname "$0")"
    pwd
)
# 引入基本巡检脚本
. "$SHELL_FOLDER"/baseinspect.sh
. "$SHELL_FOLDER"/oa_base.sh

export LANG=en_US.utf8
export LC_ALL=en_US.utf8
echoError() { echo -e $"\e[43;31;5m  "$1"\e[0m"; }
[ "$(id -u)" -gt 0 ] && echo "请用root用户执行此脚本！" && exit 1
if [ ! -f /etc/redhat-release ]; then
    echo "Sorry,This Script does't support not redhat series system!"
fi
el7=$(cat </etc/redhat-release | tr -cd "0-9" | cut -c 1)

# centosVersion=$(awk '{print $(NF-1)}' /etc/redhat-release)
function getpath() {
    java_home=$(ps -ef | grep java | grep "Xmx" | grep "com.caucho.server.resin.Resin" | grep -v monitor | grep -vi Emobile | awk '{print $8}' | awk -F "/" '{ $(NF)=$(NF-1)="";print $0}' | sed 's/[ ][ ]*/\//g' | awk 'NR==1{print}' | tr -d " ")
    resin_home=$(ps -ef | grep java | grep "Xmx" | grep "com.caucho.server.resin.Resin" | grep -v monitor | grep -vi Emobile | awk -F "-" '{ for(i=1;i<=NF;i++) {if($i ~  '/Dresin.home/'){ print $i }}}' | awk -F "=" '{print $2}' | awk 'NR==1{print}' | tr -d " ")
    if [ -z "$resin_home" ]; then
        ecology_home="default"
    else
        if [ -f "$resin_home/conf/resin.conf" ]; then
            resinconfig_path="$resin_home/conf/resin.conf"
        else
            resinconfig_path="$resin_home/conf/resin.xml"
        fi
        ecology_home=$(cat <"$resinconfig_path" | grep root-directory | grep web-app | awk 'NR==1{print}' | awk -F "\"" '{print $4}')
    fi
    read -rp "please enter the OA path(default $ecology_home): " i_oaPath
    read -rp "please enter the Resin path(default $resin_home): " i_resinPath
    read -rp "please enter the JDK path(default $java_home): " i_jdkPath
    oaPath=${i_oaPath:-"$ecology_home"}
    resinPath=${i_resinPath:-"$resin_home"}
    jdkPath=${i_jdkPath:-"$java_home"}
    if [ ! -d "$oaPath" ] || [ ! -d "$resinPath" ] || [ ! -d "$jdkPath" ]; then
        clear
        echoError "The Path the you input is Error,please retry!"
        getpath
    fi
}

while getopts ":e:r:j:t" opt; do
    case $opt in
    e)
        # echo "The ecology path is $OPTARG"
        if [ -d "$OPTARG" ]; then
            oaPath=$OPTARG
        else
            echoError "$OPTARG is not exist,the script exit,please check"
            # Usage
            exit 1
        fi
        ;;
    r)
        # echo "The resin path is $OPTARG"
        if [ -d "$OPTARG" ]; then
            resinPath=$OPTARG
        else
            echoError "$OPTARG is not exist,the script exit,please check"
            exit 1
        fi
        # [ -d "$OPTARG" ] && resinPath=$OPTARG || (echoError "$OPTARG is not exist,exit!"  && exit 1)
        ;;
    j)
        # echo "The jdk path is $OPTARG"
        if [ -d "$OPTARG" ]; then
            jdkPath=$OPTARG
        else
            echoError "$OPTARG is not exist,the script exit,please check"
            exit 1
        fi
        ;;
    t)
        # echo "The jdk path is $OPTARG"
        default_type="menu"
        # echo $2
        if [ $2 == "$default_type" ]; then
            getpath
        fi
        ;;
    ?)
        echo "The Enter Path is error,the correct useage is sh getCollection.sh -e /usr/weaver/ecology -r /usr/weaver/resin -j /usr/weaver/jdk1.8.0_151/"
        exit 1
        ;;
    esac
done

# testpar
###########check IP addr###########

function resin_path_test() {
    # echo "$1" # arguments are accessible through name, echo "$1" # arguments are accessible through , ,...,...
    # 修改resinPath 带“/” 影响resin的统计
    lastS=$(echo ${resinPath: -1})
    if [ $lastS == "/" ]; then
        resinnewPath=$(echo ${resinPath%?})
    else
        resinnewPath=$resinPath
    fi
    export resinPath=$resinnewPath
    # echo $resinPath
}

# 根据关键字解json文件，像Python字典
parse_json() {
    echo "${1//\"/}" | sed "s/.*$2:\([^,}]*\).*/\1/"
}

# 判断Resin版本
function GetResinVersion() {
    if [ ! -f "$resinPath/conf/resin.properties" ]; then
        resinversion=3
        port=$(cat <"$resinPath"/conf/resin.conf | grep address | grep -v - | awk "NR==1" | tr -cd "0-9")
        export port
    else
        resinversion=4
        port=$(grep app.http "$resinPath"/conf/resin.properties | awk 'NR==1{print}' | awk -F: '{print $2}' | tr -d ' ' | tr -d '\n' | tr -d '\r')
        export port
    fi
}


#日志相关
#是否为集群
iscluster=$(grep -c "MainControlIP" "$oaPath"/WEB-INF/prop/weaver.properties)
# redis是否启用
RedisConfPath="$oaPath"/WEB-INF/prop/weaver_new_session.properties
redis_status=$(cat "$RedisConfPath" | grep -v "^#" | grep status | awk -F "=" '{print $2}' | tr -cd "0-9")

function log_gen() {
    IPADDR="$(get_ip)"
    access_secur_first
    if [ -z $companyName ]; then
        RESULTFILE="Default""_Inspection-$IPADDR-$(date +%Y%m%d%H%M)-Resin.txt"
    else
        RESULTFILE="$companyName""_Inspection-$IPADDR-$(date +%Y%m%d%H%M)-Resin.txt"
    fi
    # echo $RESULTFILE
}

tab_top() {
    echo -n -e "+-------------------------------------------------------------------------------------------+\n"
    printf "%-1s %-8s %-1s %-16s %-1s %-13s %-1s %-20s %-1s %-20s %-1s\n" \| ID \| Item \| Value \| Std_Value \| other \|
}
tab_mod() {
    echo -n -e "+------------------+----------+---------------+----------------------+----------------------+\n"
    printf "%-1s %-8s %-1s %-16s %-1s %-13s %-1s %-20s %-1s %-20s %-1s\n" \| "$1" \| "$2" \| "$3" \| "$4" \| "$5" \|
}
tab_end() {
    echo -n -e "+-------------------------------------------------------------------------------------------+\n"
}

function os_versin() {
    if [ -f /etc/redhat-release ]; then
        os_versin=$(cat </etc/redhat-release | tr -cd '[0-9].' | tr -d ' ' | tr -d '\n' | tr -d '\r')
    else
        echoError 'This system is not belong Centos series or Red hat series'
        exit 1
    fi
    tab_top
    tab_mod 1 'Os_version' "$os_versin" '7+' 'os_version'
}

# uptime
function cpu() {
    cpu_cors=$(lscpu | grep CPU\(s\) | awk 'NR==1{print}' | awk '{print $2}')
    # echo $cpu_cors
    tab_mod 2 'Cpu_cors' "$cpu_cors" '8+' 'cpu_cors'
}

function mem() {
    mem_format=1048576
    mem_total=$(cat /proc/meminfo | grep MemTotal | awk '{print $2}')
    mem=$(echo "$mem_total" $mem_format | awk '{printf ("%.1f\n",$1/$2)}')
    useed=$(free -m | grep Mem | awk '{print $3}')
    totalm=$(free -m | grep Mem | awk '{print $2}')
    usage_percent=$(echo "$useed" "$totalm" | awk '{printf ("%.2f\n",$1/$2*100)}')
    # echo $usage_percent%
    tab_mod 3 'Total_mem' "$mem"G '16G+' 'MemoryTotal'
    tab_mod 3-1 'Mem_usage' "$usage_percent"% '<80%' 'MemUse'
}
#get disk info
function disk_info() {
    if [ "$el7" -ge 7 ]; then
        disk_use=$(df -hP "$oaPath" | awk '{print $5}' | grep -v Use | tr -cd '0-9' | tr -d ' ' | tr -d '\n' | tr -d '\r')
        tab_mod 4 'DiskUsagePer' "$disk_use"% '<80%' 'Disk_percent'
    else
        disk_use=$(df -hP "$oaPath" | awk '{print $5}' | awk 'NR==2{print}')
        tab_mod 4 'DiskUsagePer' "$disk_use" '<80%' 'Disk_percent'
    fi
}

# 获取Resin相关信息
function resin_info() {
    if [ ! -f "$resinPath/conf/resin.properties" ]; then
        export resin_display_version="Resin 3.1.8 "
        Xmx=$(grep Xmx "$resinPath"/conf/resin.conf | tr -d ' ' | tr -cd "0-9")
        thread_max=$(grep thread-max "$resinPath"/conf/resin.conf | tr -d "[:alpha:]" | tr -d "[:punct:]" | tr -d ' ' | tr -d '\n' | tr -d '\r')
        keepalivemax=$(grep keepalive-max "$resinPath"/conf/resin.conf | tr -d "[:alpha:]" | tr -d "[:punct:]" | tr -d ' ' | tr -d '\n' | tr -d '\r')
        tab_mod 8 thread_max "$thread_max" "3000" 'thread-max'
        tab_mod 9 keepalivemax "$keepalivemax" "500" 'keepalivemax'
        tab_mod 10 Xmx_mem "$Xmx" '5500M' '>5000M'
    else
        export resin_display_version="Resin 4.0.58"
        Xmx=$(grep Xmx "$resinPath"/conf/resin.properties | awk -F "-" '{ for(i=1;i<=NF;i++) {if($i ~  '/Xmx/'){ print $i }}}' | tr -cd "0-9")
        port_thread_max=$(grep port_thread_max <"$resinPath"/conf/resin.properties | awk -F : '{print $2}' | tr -d ' ' | tr -d '\n' | tr -d '\r')
        tab_mod 8 Port_thread "$port_thread_max" "3000" 'Port_thread'
        accept_thread_max=$(grep accept_thread_max <"$resinPath"/conf/resin.properties | awk -F : '{print $2}' | tr -d ' ' | tr -d '\n' | tr -d '\r')
        # export port=$(grep app.http "$resinPath"/conf/resin.properties | awk 'NR==1{print}' | awk -F: '{print $2}' | tr -d ' ' | tr -d '\n' | tr -d '\r')
        tab_mod 9 Accept_thread "$accept_thread_max" "32" 'Accept_thread'
        tab_mod 10 Xmx_mem "$Xmx" '5500M' '>5000M'
    fi
}

#redis check

function resin_process() {
    resinprocesscount=$(ps -ef | grep java | grep "Xmx" | grep "com.caucho.server.resin.Resin" | grep $resinPath | grep $resinPath/conf | grep -v monitor | wc -l)
    tab_mod 20 Resin_process "$resinprocesscount" '1' "Resin ProcessCount"

    resinwatchdogcount=$(ps -ef | grep java | grep "Xmx" | grep "com.caucho.boot.WatchdogManager" | grep $resinPath | grep -v monitor | wc -l)
    tab_mod 21 Watchdog_process "$resinwatchdogcount" '1' "Resin WatchDogCount"
}
function hotdeploy() {
    # 首先判断Resin下面agentFileNow 文件夹存在 如果存在 判断时间,如果不存在即为未启用
    if [ -e $resinPath/agentFileNow/Deploy ]; then
        # 获取watchdog最后一次启动时间
        watchdog_startime=$(cat $resinPath/log/watchdog-manager.log | grep "http listening to " | awk 'END {print}' | awk '{print $1,$2}' | tr -d '[]')
        depend_classtime=$(ls -l $resinPath/agentFileNow/Deploy/Depend.class | awk '{print $6,$7,$8}')
        watchdog_toseconds=$(date -d "$watchdog_startime" +%s)
        depend_classtime_toseconds=$(date -d "$depend_classtime" +%s)
        diff_seconds=$(($watchdog_toseconds - $depend_classtime_toseconds))
        if [ "$diff_seconds" -lt 300 ]; then
            is_hotdeploy=1
        else
            is_hotdeploy=0
        fi

    else
        is_hotdeploy=0
    fi
    tab_mod 22 Resin_hotdeploy "$is_hotdeploy" '1' "1-open0-Close"
    tab_mod 23 Resin_version "$resin_display_version" 'Resin 4.0.58' "Resin Version"

}

function savesession() {
    if [ $resinversion -eq "4" ]; then
        tab_mod 24 SaveSession "Resin4Ignore" 'False' "SaveSession"
    else
        is_session=$(cat $oaPath/WEB-INF/resin-web.xml | grep always-save-session | tr -d "" | awk -F ">" '{print $2}' | awk -F "<" '{print $1}')
        tab_mod 24 SaveSession "${is_session:-False}" 'False' "SaveSession"
    fi

}

# function UrlCharacter() {
#     if [ $resinversion -eq "4" ]; then
#         ISUrlChatacter=$(grep -c url-character $resinPath/conf/resin.xml)
#         tab_mod 29 ISUrlChatacter "$ISUrlChatacter" '1' "UrlChatacter"
#     else
#         ISUrlChatacter=$(grep -c url-character $resinPath/conf/resin.conf)
#         tab_mod 29 ISUrlChatacter "$ISUrlChatacter" '1' "UrlChatacter"
#     fi

# }

function EcodeVersion() {
    if [ -f "$oaPath"/ecode/version.json ]; then
        EcodeVersion=$(cat "$oaPath"/ecode/version.json | awk 'NR==2{print}' | awk -F ":" '{print $2}' | tr -d "\"" | tr -d "\r")
        tab_mod 37 EcodeVersion "$EcodeVersion" "1.9" "EcodeVersion"
    fi
}

function ResinLog() {
    # 检测ecology日志文件大小

    resin_log_dir="$resinPath"/logs
    resin_log_size=$(du -sh $resin_log_dir --block-size m | awk '{print $1}' | tr -d "M")
    if [ $resinversion -eq "4" ]; then
        PFixFilter=$(grep -c weaver.filter.PFixFilter "$oaPath"/WEB-INF/resin-web.xml)
        tab_mod 36 PFixFilter "$PFixFilter" "0" "Sessionfailure"
    fi

    tab_mod 35 resin_log_size "$resin_log_size" "<20480" "resin_log_size"
    

    # redis session在启用redis的情况下,需要更新补丁
    if [ $redis_status -eq "1" ] && [ -f $oaPath/WEB-INF/ecology.ver ]; then
        if [ -f $oaPath/classbean/weaver/interfaces/schedule/RedisCleanJob.class ]; then
            # True代表已经升级过此补丁包
            tab_mod 40 Redisoptimize "True" "True" "Redisoptimize"
        else
            tab_mod 40 Redisoptimize "False" "True" "Redisoptimize"
        fi
    fi
    #memmonitor.class 判断memmonitor.class 去除内存大于90的判断
    # if [ $resinversion -eq "4" ] && [ -f "$oaPath/WEB-INF/classes/weaver/monitor/monitor/MemMonitor.class" ]; then
    #     is_true=$($jdkPath/bin/java -jar jd-cli.jar "$oaPath/WEB-INF/classes/weaver/monitor/monitor/MemMonitor.class" | grep 90.0F | wc -l)
    #     if [ $is_true -ge 1 ]; then
    #         # 如果为true代表有这个bug
    #         tab_mod 41 MemMonitor "True" "False" "MemMonitor"
    #     else
    #         tab_mod 41 MemMonitor "False" "False" "MemMonitor"
    #     fi
    # fi
}


function RedisBigKey() {
    # 反编译redissessionutil$1.class 判断是否有redis
    # 第一种 没有过滤到 那就是没有打redis优化包
    # 第二种 过滤到了 代表打过这个补丁包 需要提示重新打
    # 第三种 过滤到了 并且有最新的代码 提示通过
    if [ -f $oaPath/WEB-INF/ecology.ver ];then
        RedisDecomplieCode=$($jdkPath/bin/java -jar jd-cli.jar $oaPath/classbean/weaver/session/util/RedisSessionUtil\$1.class)
        # GrepResult=$(echo $RedisDecomplieCode | grep "sessionKeyCreateTimeList.add" | wc -l)
        if [ $(echo $RedisDecomplieCode | grep 'arrayList1.add(sessionId)' | wc -l) -eq 0 ]; then
                tab_mod 42 "RedisBigKey" "不通过" "通过" "E9Redis大key"
            else
                tab_mod 42 "RedisBigKey" "通过" "通过" "E9Redis大key"
            fi
    fi
    # 检测OA是否开启自启
    isEnableOA=$(cat /etc/rc.d/rc.local |grep $resinPath|wc -l)
    tab_mod 42 "OAAutoStart" "$isEnableOA" "1" "OA开机自启"
    

}
# 检测服务abrtd状态
function AbrtdCheck() {
    if [ "$el7" -ge 7 ]; then
        # Centos7 及以上
        isEnable=$(systemctl status abrtd 2>&1 |grep running|wc -l)
    else
        isEnable=$(service abrtd status 2>&1|grep running|wc -l)
    fi
    tab_mod 43 "AbrtdStatus" "$isEnable" "0" "Abrtd服务状态"
    # (1代表开启,0代表关闭)
}

broken_link() {
    echo ""
    echo '############################ ecology软连接损坏 #############################'
    a=$(find $oaPath -type l)
    if [ ! -z "$a" ]; then
        for i in $(echo $a); do file $i; done | grep -i broken 2>/dev/null
    else
        echo "未做文件共享,跳过!"
    fi
}

access_secur() {
    echo ""
    echo '############################ 安全包状态检测 #############################'
    echo Start checking the Security Url
    echo ''
    url='http://127.0.0.1:'$port"/security/monitor/MonitorStatusForServer.jsp"
    echo $url
    # echo "This step will take a long time, please be patient."
    resutl=$(curl -s $url >test.txt)
    if [ $? != 0 ]; then
        echo 'Access Security page error,please insure the resin has been started! '
        return 0
    fi
    fin=$(grep -v '^$' test.txt | tr -d ' ' | tr -d '\r' | tr -d "\n")
    # tr -d '\r'  返回的接口信息中有回车， 需要删掉，不然解析会失败
    if [ -e dc16.jar ]; then
        if [[ -n $fin ]]; then
            returnMsg=$("$jdkPath"/bin/java -jar ./dc16.jar "$fin" "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAK2yDkw/1A946hhzvW3t4AOcsamMMnf3klqw3rZMaGWbPckzWqxl1RGtTVMoJauWZpjo+qCn3jp8RbFh6gTQE9lI61hVB/MBDKwGUq9bA5msxyDno1C5Cn0fZa6xY7BAM/JQemTtPoHo/m2y6GeXR9tjZdeIQGdb5doXA1hMvUlJAgMBAAECgYBt6j8iAUIwiFObJaK57c3Ue1Px9sX5JLF4snQ86B0oLxTqPZUjg01R4lkMRluQOZyzJrty7seyOvHfThbI9OOZkW+cnIAVq65gvj6LqnEd4upl9I+f+WmQSuBUN/Pjtx8A5PPujOXIV1g+7fL5JDfzXyfzi4banL97dSx9mxqIAQJBANu8QI9ts9EMlaoolck5O6xrACzvipwcJJbM2U2w/vQWFgjylGB4Q5wgcCGEeZRF64ovDcZxNSb4hmKqvwSVzJMCQQDKXKLCQ9BM0JpuJOckxfhYzXSvtG/vC4U/NeBNISOZiC5thoJSkyY4H27pk32rynuOxhSAQ4D/0+TDHKGIAVgzAkA2Ex3QLi8SQwaR2WsDGhKVW7+vT0PNJx/Z/I99jxEvAEBr80aQdwgsY880cGV7F7nfR7UcIL/z1zU7EsnvVu4BAkEArXHw3ukY5H33n2hp5Y75acPPu7nAJveM4bzf37wDs1iR0rZzhSsymu/2NKWCFXibpqgIcldpfdy0OreTi+r7GQJAe3vPc6J5+2JSwqCY9OSeq+MS8kAZbWMkeC4M4ai8c7BhYED/2664qCuab7v5U/VUMbhbhy+h3lq7TdjV+1xKmA==" | tr -d ' ')
            # returnMsg=$($jdkPath/bin/java -jar ./AESCoder.jar $fin | tr -d ' ')
            # 返回的消息里面带有空格，需要去掉，必然解析会有错误
            echo "Response Content"
            echo $returnMsg
            # exit 0
            firewallstatus=$(parse_json $returnMsg "firewallStatus")
            AutoUpdateStatus=$(parse_json $returnMsg "autoUpdateStatus")
            SoftwareVersion=$(parse_json $returnMsg "softwareVersion")
            remote_stat=$(echo $returnMsg | grep remoteVersion | wc -l)
            companyName=$(parse_json $returnMsg "companyName")
            ecVersion=$(parse_json $returnMsg "ecVersion")
            # echo $remote_stat
            if [ $remote_stat -gt 0 ]; then
                RemoteVersion=$(parse_json $returnMsg "remoteVersion")
            else
                RemoteVersion='not found'
            fi
            echo firewallstatus: $firewallstatus
            echo AutoUpdateStatus: $AutoUpdateStatus
            echo SoftwareVersion: $SoftwareVersion
            echo RemoteVersion: $RemoteVersion
            echo companyName:$companyName
            echo ecVersion:$ecVersion
        else
            echo 'Decrypt Error,Plase Check!'
        fi
    else
        echo 'AESCoder.jar Could not find in this dictory ,Please Check!'
    fi
}
function resin_jvm_args() {
    isExistCache=$(ps -ef | grep java | grep "Xmx" | grep "com.caucho.server.resin.Resin" | grep $resinPath | grep $resinPath/conf | grep -v monitor|grep ReservedCodeCacheSize | wc -l)
    tab_mod 301 JVM_Args "$isExistCache" '1' "ReservedCodeCacheSize"
}

# access_secur_first
function ecology_check() {
    redis_check
    hdparmtest
    sysstat_test
    os_versin
    cpu
    mem
    disk_info
    ip_check
    file_jdk
    resin_info
    db_conn
    redis_connect
    weaver_info
    firewall
    resin_process
    hotdeploy
    savesession
    OtherWeaverService
    JDKStats
    Ec_Version
    NFSMountDumplicate
    EcologyLog
    ResinLog
    EcodeMSGE
    PersonaTest
    RedisBigKey
    AbrtdCheck
    WebXmlFilter
    oa_base_main
    doc_sensitive_words
    HandleTimerTask
    docpreview
    #301
    resin_jvm_args
    #302
    ecology_WEBINF_prop_exceeds10mb
    tab_end
    check_web_xml_sequence
    broken_link
    Cluster_check
    access_secur
    disk_speed
    check
}
function main() {
    # echo $RESULTFILE
    #执行检查并保存检查结果
    # getpath
    GetResinVersion
    resin_path_test
    log_gen
    ecology_check | tee "$RESULTFILE"
    echo "检查结果：$RESULTFILE"
    echo ''

}
main
