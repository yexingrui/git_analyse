#!/bin/bash
#---------------------------------------------------------------------------
# File: menu.sh
# Created Date: 2022-06-24
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# Last Modified: Friday June 24th 2022 11:38:10 am
# Copyright (c) 2022 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
[ $(id -u) -gt 0 ] && echo "请用root用户执行此脚本！" && exit 1


function menu ()
{
 echo -e "\033[35m ---------------------------------------
|************Menu Home Page ************|
----------------------------------------\033[0m"


PS3="Enter Option: "
select option in  "服务器巡检修复" "OA巡检修复" "Exit menu"
do 
    case $option in
    "Exit menu")
        exit 0
        ;;
    "服务器巡检修复")
        bash os_repair.sh
        menu
          ;;
    "OA巡检修复")
        bash oa_repair.sh
        menu
         ;;
    *)
        clear
        echo "sorry,wrong selection" ;;
    esac
done
clear
}

menu