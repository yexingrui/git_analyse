#!/bin/bash
#---------------------------------------------------------------------------
# File: oa_repair.sh
# Created Date: 2022-06-24
# Author: sunzhe
# Contact: <sunzhenet@163.com>
# Last Modified: Friday June 24th 2022 11:44:32 am
# Copyright (c) 2022 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
function get_ip() {
    ip=$(ip -o route get to 223.5.5.5 | sed -n 's/.*src \([0-9.]\+\).*/\1/p')
    echo "$ip"

}
IPADDR="$(get_ip)"

RESULTFILE="Ecology_repair-$IPADDR-$(date +%Y%m%d).txt"
function getpath() {
    java_home=$(ps -ef | grep java | grep "Xmx" | grep "com.caucho.server.resin.Resin" | grep -v monitor | grep -vi Emobile | awk '{print $8}' | awk -F "/" '{ $(NF)=$(NF-1)="";print $0}' | sed 's/[ ][ ]*/\//g' | awk 'NR==1{print}' | tr -d " ")
    resin_home=$(ps -ef | grep java | grep "Xmx" | grep "com.caucho.server.resin.Resin" | grep -v monitor | grep -vi Emobile | awk -F "-" '{ for(i=1;i<=NF;i++) {if($i ~  '/Dresin.home/'){ print $i }}}' | awk -F "=" '{print $2}' | awk 'NR==1{print}' | tr -d " ")
    if [ -z "$resin_home" ]; then
        ecology_home="default"
    else
        if [ -f "$resin_home/conf/resin.conf" ]; then
            resinconfig_path="$resin_home/conf/resin.conf"
        else
            resinconfig_path="$resin_home/conf/resin.xml"
        fi
        ecology_home=$(cat <"$resinconfig_path" | grep root-directory | grep web-app | awk 'NR==1{print}' | awk -F "\"" '{print $4}')
    fi
    read -rp "please enter the OA path(default $ecology_home): " i_oaPath
    read -rp "please enter the Resin path(default $resin_home): " i_resinPath
    read -rp "please enter the JDK path(default $java_home): " i_jdkPath
    oaPath=${i_oaPath:-"$ecology_home"}
    resinPath=${i_resinPath:-"$resin_home"}
    jdkPath=${i_jdkPath:-"$java_home"}
    if [ ! -d "$oaPath" ] || [ ! -d "$resinPath" ] || [ ! -d "$jdkPath" ]; then
        clear
        echoError "The Path the you input is Error,please retry!"
        getpath
    fi
}

# 获取Resin相关信息
function resin_info() {
    echo ""
    echo ""
    echo "############################ Resin XMX修复 #############################"
    echo ""
    # 获取内存信息
    MemTotal=$(grep MemTotal /proc/meminfo | awk '{print $2}') #KB
    report_MemTotal="$((MemTotal / 1024))"                     #内存总容量(MB)
    if [ -f "$resinPath/conf/resin.properties" ]; then
        Xmx=$(grep Xmx "$resinPath"/conf/resin.properties | awk -F "-" '{ for(i=1;i<=NF;i++) {if($i ~  '/Xmx/'){ print $i }}}' | tr -cd "0-9")
        if [[ $report_MemTotal -lt 8192 ]]; then
            if [ -d /usr/emp ]; then
                echo "内存小于8G,且存在/usr/emp,修改内存为3250m"
                echo 'Found emp'
                sed -i "s/$Xmx/3250/g" $resinPath/conf/resin.properties
                echo "Change $Xmx to 3250m success"
            else
                echo "内存小于8G,且不存在/usr/emp,修改内存为5550m"
                sed -i "s/$Xmx/5550/g" $resinPath/conf/resin.properties
                echo "Change $Xmx to 5500m success"
            fi
        elif [ $report_MemTotal -gt 8192 -a $report_MemTotal -lt 16384 ]; then
            echo "操作系统内存大于8G,小于16G,修改XMX为5500"
            sed -i "s/$Xmx/5550/g" $resinPath/conf/resin.properties
            echo "Change $Xmx to 5550m success"
        else
            echo "操作系统内存大于16G,修改XMX为8500"
            sed -i "s/$Xmx/8550/g" $resinPath/conf/resin.properties
            echo "Change $Xmx to 8550m success"
        fi
    else
        Xmx=$(grep Xmx $resinPath/conf/resin.conf | tr -d ' ' | cut -c 14-18)
        echo "Resin3 XMX修改"
        if [[ $report_MemTotal -lt 8192 ]]; then
            echo "内存小于8G修改内存为3250m"
            sed -i "s/$Xmx/3250/g" $resinPath/conf/resin.conf
            echo "Change $Xmx to 3250m success"
        elif [ $report_MemTotal -gt 8192 -a $report_MemTotal -lt 16384 ]; then
            echo "操作系统内存大于8G,小于16G,修改XMX为5500"
            sed -i "s/$Xmx/5550/g" $resinPath/conf/resin.conf
            echo "Change $Xmx to 5550m success"
        else
            echo "操作系统内存大于16G,修改XMX为8500"
            sed -i "s/$Xmx/8550/g" $resinPath/conf/resin.conf
            echo "Change $Xmx to 8550m success"
        fi
    fi
}
function repair_OAAutoStart() {
    echo ""
    echo ""
    echo "############################ OA开机自启动 #############################"
    echo ""
    # 判断/etc/rc.d/rc.local中是否存在Resin路径
    isExistResin=$(cat /etc/rc.d/rc.local | grep $resinPath | wc -l)
    if [ $isExistResin -gt 0 ]; then
        echo "OA已配置开机自启,跳过修复"
    else
        echo "开始配置OA开机自启"
        echo "$resinPath/bin/startresin.sh" >>/etc/rc.d/rc.local
        chmod 755 /etc/rc.d/rc.local
        echo "OA开机自启修复成功"
    fi
}

function repair_StopHotdeploy() {
    echo ""
    echo ""
    echo "############################ 禁用Resin热部署 #############################"
    echo ""
    # 判断是否为resin,且获取Resin的版本
    if [ -f $resinPath/conf/resin.conf ]; then
        # resin3 判断是否存在
        isConfigStopHot=$(grep -w "\-javaagent:stophotdeploy.jar" $resinPath/conf/resin.conf | wc -l)
        if [ $isConfigStopHot -eq 0 ]; then
            cp ./stophotdeploy.jar $resinPath
            sed -i.bak '/-Dfile.encoding/a <jvm-arg>-javaagent:stophotdeploy.jar</jvm-arg>' $resinPath/conf/resin.conf
            echo "Resin3 stophotdeploy修复成功!"
        else
            echo "Resin3已配置禁用热部署,跳过修复!"
        fi
    elif [ -f $resinPath/conf/resin.properties ]; then
        # resin4
        isConfigStopHot=$(grep -w "\-javaagent:stophotdeploy.jar" $resinPath/conf/resin.properties | wc -l)
        if [ $isConfigStopHot -eq 0 ]; then
            cp ./stophotdeploy.jar $resinPath
            sed -i.bak '/jvm_args/s/$/ -javaagent:stophotdeploy.jar/' $resinPath/conf/resin.properties
            echo "Resin4 stophotdeploy修复成功!"
        else
            echo "Resin4已配置禁用热部署,跳过修复!"
        fi
    else
        echo "无法判断Resin版本,跳过修复!"
    fi
}

function repair_SQLCache() {
    echo ""
    echo ""
    echo "############################ SQL缓存修复 #############################"
    echo ""
    if [ -f "$oaPath"/WEB-INF/prop/initCache.properties ]; then
        iscache=$(grep "iscache" "$oaPath"/WEB-INF/prop/initCache.properties | sed -e 's/\r//g' | grep -v "#" | grep -v 'update' | awk -F "=" '{print $2}')
        if [ $iscache -eq 0 ]; then
            sed -i 's/iscache=0/iscache=1/g' "$oaPath"/WEB-INF/prop/initCache.properties
            echo "修改initCache.properties成功"
        fi
    else
        echo "未找到initCache.properties,跳过修复"
    fi
}

function repair_OARef() {
    getpath
    resin_info
    repair_OAAutoStart
    repair_StopHotdeploy
    repair_SQLCache
}
repair_OARef | tee "$RESULTFILE"
