#!/bin/bash
#---------------------------------------------------------------------------
# File: repair.sh
# Created Date: 2020-12-28
# Author: sunzhe
# Contact: <sunzhenet@163.com>
#
# Last Modified: Friday June 24th 2022 11:30:33 am
#
# Copyright (c) 2020 Weaver
# It is never too late to be what you might have been.
# Dec:
# -----
# HISTORY:
# Date      	 By	Comments
# ----------	---	----------------------------------------------------------
#---------------------------------------------------------------------------
# 解析参数
[ $(id -u) -gt 0 ] && echo "请用root用户执行此脚本！" && exit 1


#check system version
el7=$(uname -r | grep -c "el7")
function get_ip() {
    ip=$(ip -o route get to 223.5.5.5 | sed -n 's/.*src \([0-9.]\+\).*/\1/p')
    echo "$ip"

}
IPADDR="$(get_ip)"

RESULTFILE="OS_repair-$IPADDR-$(date +%Y%m%d).txt"

# hostname -i 解析修复
function ip_check() {
    echo ""
    echo ""
    echo "############################ Linux主机名解析 #############################"
    echo ""
    ip=$(ip -o route get to 223.5.5.5 | sed -n 's/.*src \([0-9.]\+\).*/\1/p')
    hostname=$(hostname -i)
    containLocalhost=$(echo $(hostname)|grep localhost|wc -l)
    if [[ $ip != $hostname ]]||[ $containLocalhost -gt 0 ]; then
        # 删除所有localhost
        sed -i.bak '/localhost/d' /etc/hosts
        # 删除所有当前IP配置的hosts解析
        sed -i.bak "/$ip/d" /etc/hosts
        # 如果主机名为localhost 自动生成一个随机主机名,格式为Ecology+3为随机数字
        generHostName="Ecology""$(echo $RANDOM)"
        if [ $containLocalhost -gt 0 ]; then
            echo $ip $generHostName >>/etc/hosts
            echo "修改主机名"
            if [ -f /etc/os-release ]; then
                echo "Centos7以上修复主机名"
                hostnamectl set-hostname $generHostName
            else
                echo "Centos6修改主机名"
                echo "HOSTNAME=$generHostName" >> /etc/sysconfig/network
            fi
        else
            # 客户指定主机名
            echo "使用$hostname设置/etc/hosts"
            echo $ip $(hostname) >> /etc/hosts
        fi
        echo "主机名修复成功"
    else
        echo "主机名配置正确,跳过修复"
    fi

}

# 打开文件数修复
function open_files() {
    echo ""
    echo ""
    echo "############################ 打开文件数修复 #############################"
    echo ""
    open_files=$(ulimit -n)
    if [ $open_files -ge 65535 ]; then
        echo "打开文件数大于等于65535,跳过修复!"
    else
        result=$(grep nofile /etc/security/limits.conf | grep -v "#" | wc -l)
        if [[ $result = 0 ]]; then
            echo "* soft nofile 65535" >>/etc/security/limits.conf
            echo "* hard nofile 65535" >>/etc/security/limits.conf
            echo "打开文件数修复成功"
        fi
    fi
}

# ntp配置
function ntp_config() {
    # 先检测是否可以上外网
    # 判断系统版本 如果os-release存在 则使用chronyd,如果不存在则使用ntpdate
    echo ""
    echo ""
    echo "############################ 配置NTP时间同步 #############################"
    echo ""
    return_code=$(curl -I -m 10 -o /dev/null -s -w %{http_code} www.baidu.com)
    if [ $return_code -eq 200 ]; then
        if [ -f /etc/os-release ]; then
            # centos7 及以上
            systemctl start chronyd && systemctl enable chronyd
            echo "Centos7及以上Chronyd配置成功"
        else
            # centos6
            ntpdate ntp.aliyun.com >/dev/null 2>&1
            if [ $? -ne 0 ]; then
                yum install ntpdate -y
                echo "*/5 * * * *  /usr/sbin/ntpdate ntp.aliyun.com" >>/etc/crontab
                echo "Centos6 NTP配置成功"
            else
                is_config_ntp=$(cat /etc/crontab | grep ntpdate | wc -l)
                if [ $is_config_ntp -eq 0 ]; then
                    echo "*/5 * * * *  /usr/sbin/ntpdate ntp.aliyun.com" >>/etc/crontab
                    echo "Centos6 NTP配置成功"
                else
                    echo "ntpdate already in crontab,skip"
                fi
            fi
        fi
    else
        echo "Can not access internet,skip!"
    fi

}

# timewait 修复
function time_wait_repair() {
    echo ""
    echo ""
    echo "############################ TIME-WAIT修复 #############################"
    echo ""
    
    timewait=$(ss -tan | awk 'NR>1{++S[$1]}END{for (a in S) print a,S[a]}' | grep TIME-WAIT | awk '{print $2}')
    if [[ $timewait > 2000 ]]; then
        echo "TIME-WAIT连接数$timewait大于2000,开始修复"
        OIFS=$IFS
        IFS=$'/'
        test_array=("net.ipv4.tcp_fin_timeout=30"/"net.ipv4.tcp_keepalive_time=1200"/"net.ipv4.tcp_syncookies=1"/"net.ipv4.ip_local_port_range=10000 65000"/"net.ipv4.tcp_max_syn_backlog=8192"/"net.ipv4.tcp_max_tw_buckets=5000")
        for i in ${test_array[@]}; do
            is_exist=$(grep $i /etc/sysctl.conf | wc -l)
            if [[ $is_exist > 0 ]]; then
                echo "$i already exists,skip!"
            else
                echo $i >>/etc/sysctl.conf
            fi
        done
    else
        echo "TIME-WAIT连接数$timewait小于2000,跳过修复"
        # 将分隔符改为默认分隔符
        IFS=$OIFS
        sysctl -p 2>&1 >/dev/null
    fi

}

function repair_Abrtd() {
    echo ""
    echo ""
    echo "############################ Abrtd服务状态 #############################"
    echo ""
    if [ -f /etc/os-release ]; then
        # centos7及以上
        echo "Centos7及以上,禁用Abrtd服务"
        systemctl stop abrtd && systemctl disable abrtd
    else
        echo "Centos6,禁用abrtd服务"
        service abrtd stop && chkconfig abrtd off
    fi

}

function repair_Swap() {
    echo ""
    echo ""
    echo "############################ 虚拟内存 #############################"
    echo ""
    # 获取当前虚拟内存大小
    swapMem=$(cat /proc/meminfo |grep SwapTotal|awk '{print $2}')
    if [ $swapMem -eq 0 ];then
        echo "开始创建虚拟内存"
        dd if=/dev/zero of=/home/swap bs=1G count=4
        mkswap /home/swap
        chmod 600 /home/swap
        swapon /home/swap
        echo "添加swap挂载到/etc/fstab"
        echo "/home/swap swap swap default 0 0" >> /etc/fstab
    else
        echo "已配置虚拟内存,跳过配置!"
    fi
}

function repair_SwapKernel(){
    echo ""
    echo ""
    echo "############################ 虚拟内存(swappiness参数) #############################"
    echo ""
    isExsitSwappniess=$(cat /etc/sysctl.conf|grep vm.swappiness|wc -l)
    if [ $isExsitSwappniess -gt 0 ]; then
        echo "修改vm.swappiness为30"
        sed -i.bak '/vm.swappiness/d' /etc/sysctl.conf
        echo "vm.swappiness =30" >> /etc/sysctl.conf
        echo "修改vm.swappiness成功"
    else
        echo "未设置vm.swappiness,跳过修复!"
    fi
}



function repair_TcpReuse() {
    echo ""
    echo ""
    echo "############################ Linux TCP 重用配置 #############################"
    echo ""
    isTcpReuse=$(sysctl net.ipv4.tcp_tw_reuse|awk '{print $3}')
    if [ $isTcpReuse -eq 1 ];then
        echo "检测到开启了TCP_Reuse,修改内核参数"
        sed -i.bak '/net.ipv4.tcp_tw_reuse/d' /etc/sysctl.conf
        echo "net.ipv4.tcp_tw_reuse=0" >> /etc/sysctl.conf
        sysctl -p
    else
        echo "跳过修复Linux TCP 重用"
    fi
}



function repair_OSRef() {
    ip_check
    open_files
    ntp_config
    time_wait_repair
    repair_Abrtd
    repair_Swap
    repair_SwapKernel
    repair_TcpReuse
}
#执行检查并保存检查结果

repair_OSRef |tee $RESULTFILE


